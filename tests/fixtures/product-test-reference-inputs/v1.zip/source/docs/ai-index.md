# AI Index

For current pilot and central operations, start with the
[operations handbook](operations/guides/governance-repository-operations-handbook.md).
It links the [daily report](operations/status/daily-governance-operations.md),
[access maintenance](operations/security/github-access-and-token-maintenance.md),
and [backup and recovery](operations/processes/governance-repository-backup-and-recovery.md).
Dated reference runs and released documentation remain historical evidence.

## Purpose

This index helps AI agents and human maintainers find the right files before changing the repository.

Use it as the first navigation point after `AGENTS.md`.

## Fast Orientation

| Need | Read first |
|---|---|
| Find detailed repository functions and implementation boundaries | `docs/operations/guides/repository-function-catalog.md` |
| Operate Mac and VM independently; inspect installed versus merged source | `docs/operations/guides/linux-vm-installation.md`, `docs/operations/status/current-governance-platform-state.md` |
| Inspect merged portability and remaining live acceptance | `docs/operations/planning/platform-portability-acceptance.md`, `docs/operations/status/repository-documentation-reconciliation-2026-11-15.md` |
| Understand the repository | `README.md`, `docs/official-entrypoints.md` |
| Understand the current technical system architecture (arc42: context, components, runtime, deployment, quality and risks) | `docs/governance/architecture/governance-as-code-system-architecture.md` |
| Trace a source document through canonical requirements to executable OPA policy | `docs/governance/architecture/document-intake-to-opa-rulebook.md` |
| Understand foundation, direction, and architectural guardrails | `docs/foundation/01_VISION.md`, `docs/foundation/02_CONSTITUTION.md`, `docs/foundation/03_ARCHITECTURE_PRINCIPLES.md`, `docs/foundation/05_CURRENT_DIRECTION.md` |
| Run the live demo | `docs/demos/demo-end-to-end-governance.md` |
| Understand current ha-CPsWMS status | `docs/operations/status/ha-cpswms-governance-validation-status.md`, `docs/demos/ha-cpswms-architecture-governance-results.md` |
| Understand source-document lineage | `generated/reports/source-lineage-report.md` |
| See which registered sources currently feed models and which remain under review | `docs/operations/guides/source-document-dependency-map.md` |
| Classify a new artifact before adding it | `docs/operations/processes/new-artifact-intake-process.md` |
| Understand the modular Git-native documentation publication model | `docs/operations/planning/doc-as-code-architecture-decision.md`, `docs/publishing/doc-as-code-pilot/publication.yaml`, `docs/publishing/doc-as-code-pilot/requirements/`, `doc-as-code/`, `docs/governance/change-requests/GCR-2026-141-modular-doc-as-code-model.md` |
| Operate the hybrid document-to-Git requirement lifecycle | `docs/operations/processes/hybrid-requirement-lifecycle.md`, `model/requirements/requirement-authority-ledger.yaml`, `model/requirements/governance-requirement-catalog.yaml`, `model/requirements/lifecycle-cases/`, `docs/governance/change-requests/GCR-2026-143-hybrid-requirement-lifecycle.md` |
| Add a new artifact safely | `docs/operations/guides/how-to-add-a-new-artifact.md` |
| Intake updated input documents | `docs/governance/governance-change-lifecycle.md`, `docs/operations/processes/source-document-intake-process.md`, `docs/operations/processes/source-document-intake-review-operating-model.md`, `model/documents/source-document-register.yaml` |
| Operate guided private source intake and review | `docs/operations/guides/governance-review-workbench.md`, `scripts/serve_governance_workbench.py` (local maintainer app; proposal-only; optional Draft-PR adapter) |
| Understand ADO and DevSecOps-as-Code as one system | `docs/governance/architecture/ado-devsecops-integrated-governance-model.md` |
| Explain the repository as an answer to software industrialisation problems | `docs/governance/architecture/software-industrialisation-problem-capability-map.md` |
| Compare governance with central repository versus without central repository | `docs/governance/architecture/governance-repository-architecture-comparison.md` |
| Classify documentation and plan safe docs restructuring | `docs/operations/planning/document-structure-model.md` |
| Understand the accepted document consistency review Phase 0 and bounded pilot | `docs/operations/planning/document-consistency-review-workpackage.md`, `docs/operations/planning/document-consistency-review-adr.md`, `docs/governance/change-requests/GCR-2026-116-document-consistency-review.md` |
| Understand the accepted bounded document consistency review Phase 1 structure core | `docs/governance/change-requests/GCR-2026-118-document-consistency-review-phase1.md`, `scripts/generate_document_consistency_review_manifest.py`, `scripts/generate_document_consistency_review_model.py`, `scripts/validate_document_consistency_review.py` |
| Decide the bounded document consistency review Phase 2 semantic pilot | `docs/operations/planning/document-consistency-review-phase2-decision-brief.md`, `docs/governance/change-requests/GCR-2026-119-document-consistency-review-phase2-decision.md` (one bounded run executed; schema-invalid output rejected) |
| Inspect the bounded semantic pilot observation | `docs/operations/reference-runs/2026-10-07-document-consistency-semantic-pilot.md`, `docs/governance/change-requests/GCR-2026-123-document-consistency-semantic-pilot-observation.md` (no validated finding; raw response deleted; rollout pending) |
| Inspect the validated second semantic pilot | `docs/operations/reference-runs/2026-10-07-document-consistency-semantic-pilot-2.md`, `docs/examples/document-consistency-review-phase2-live-pilot-report.json`, `docs/governance/change-requests/GCR-2026-125-document-consistency-semantic-pilot-2.md` (`partial`, zero candidates, no consistency claim, rollout pending) |
| Validate Phase 2 semantic responses | `docs/operations/guides/document-consistency-semantic-review.md`, `docs/governance/change-requests/GCR-2026-120-document-consistency-phase2-infrastructure.md`, `scripts/validate_document_consistency_semantic_review.py` (synthetic fixtures and fail-closed provider-output validation) |
| Adapt provider output for Phase 2 validation | `docs/governance/change-requests/GCR-2026-124-document-consistency-provider-neutral-stabilization.md`, `scripts/adapt_document_consistency_provider_response.py`, `model/governance/document-consistency/provider-adapter-config-v1.json` (provider-neutral normalization; no provider call or approval) |
| Evaluate semantic providers against curated cases | `docs/governance/change-requests/GCR-2026-126-document-consistency-semantic-evaluation-catalog.md`, `docs/governance/change-requests/GCR-2026-136-document-consistency-catalog-v2.md`, `model/governance/document-consistency/semantic-evaluation-catalog-v1.json`, `model/governance/document-consistency/semantic-evaluation-catalog-v2.json`, `scripts/evaluate_document_consistency_semantic_report.py` (synthetic bounded metrics; real reports require matching approved ground truth) |
| Prepare a blinded semantic catalog run | `docs/governance/change-requests/GCR-2026-127-document-consistency-semantic-catalog-run-package.md`, `scripts/prepare_document_consistency_semantic_catalog_run.py`, `model/governance/document-consistency/semantic-catalog-prompt-v1.txt` (six-file provider input; provider and model remain unbound) |
| Inspect blinded semantic catalog run 0001 | `docs/operations/reference-runs/2026-10-07-document-consistency-semantic-catalog-run-0001.md`, `docs/examples/document-consistency-semantic-catalog-run-0001-report.json`, `docs/examples/document-consistency-semantic-catalog-run-0001-evaluation.json`, `docs/governance/change-requests/GCR-2026-128-document-consistency-semantic-catalog-run-0001.md` (3/3 bounded synthetic cases passed; one finding remains unconfirmed; rollout pending) |
| Inspect the human decision for catalog run 0001 | `docs/examples/document-consistency-semantic-catalog-run-0001-human-decision.json`, `docs/governance/change-requests/GCR-2026-129-document-consistency-catalog-human-decision.md` (`DCR-SEM-001` classified `helpful` for the synthetic case; no normative resolution; rollout pending) |
| Present the Document Consistency Review | `docs/demos/presentation-guide-document-consistency-review-de.md` (German speaker guide, architecture, functions, methods, security boundaries, evidence and live demo) |
| Assess Document Consistency Review rollout readiness | `docs/operations/status/document-consistency-rollout-readiness.md`, `docs/operations/status/document-consistency-rollout-management-summary.md`, `model/governance/document-consistency/rollout-decision-v2.json` (`limited_pilot_ready` for separately authorized report-only runs; production pending) |
| Review completion of WP-DCR-001 | `docs/operations/status/document-consistency-workpackage-completion-review.md`, `docs/governance/change-requests/GCR-2026-132-document-consistency-completion-review.md`, `docs/governance/change-requests/GCR-2026-133-document-consistency-pilot-acceptance.md` (accepted as a bounded report-only pilot on 2026-10-08; production remains pending) |
| Approve one-time public publication of the redacted DCR pilot projection | `docs/governance/change-requests/GCR-2026-138-dcr-viewer-publication.md` (one existing report only; no production rollout, recurring publication or automatic execution) |
| Prepare a separately authorized DCR method comparison | `docs/governance/change-requests/GCR-2026-135-document-consistency-method-comparison-proposal.md` (second-provider synthetic comparison proposed; execution not authorized) |
| Track future model-driven document generation | `docs/operations/planning/model-driven-governance-documentation-backlog.md` (`WP-MDG-001`, deferred and separately authorized) |
| View the redacted Document Consistency Review projection | `docs/operations/guides/governance-viewer-app.md`, `docs/governance/change-requests/GCR-2026-121-document-consistency-phase3-viewer.md`, `docs/governance/change-requests/GCR-2026-138-dcr-viewer-publication.md`, `scripts/lib/document_consistency_view.py` (one existing report may be published; broader publication remains unauthorized) |
| Operate the provider-neutral Document Consistency Review lifecycle | `docs/operations/guides/document-consistency-review-operations.md`, `docs/governance/change-requests/GCR-2026-122-document-consistency-phase4-operations.md`, `model/governance/document-consistency/`, `scripts/validate_document_consistency_review_operations.py` (candidate infrastructure; rollout pending) |
| Plan the closed-loop finding, decision and remediation pilot | `docs/operations/planning/closed-loop-governance-implementation-plan.md` (CLG-01–06.3 implementation and accepted limited GitHub pilot) |
| Assess capacity for 300 to 1,500 consumer repositories | `docs/operations/planning/consumer-scale-capacity-assessment.md`, `scripts/simulate_consumer_scale.py` |
| Inspect CLG-01 contracts and open pilot decisions | `docs/operations/evidence/governance-lifecycle-contract.md`, `docs/operations/evidence/governance-lifecycle-pilot-decisions.md` (offline contracts; separate accepted live pilot) |
| Use the CLG-02 synthetic finding/event kernel | `docs/operations/evidence/governance-lifecycle-kernel.md`, `scripts/intake_governance_lifecycle_observation.py`, `status/governance-lifecycle-synthetic-index.json` (synthetic only) |
| Use CLG-03 synthetic decision and remediation intake | `docs/operations/evidence/governance-lifecycle-decisions.md`, `scripts/intake_governance_lifecycle_action.py` (test consent; separate personal live action path) |
| Run the CLG-04 synthetic closure pilot | `docs/demos/demo-governance-lifecycle-pilot.md`, `docs/operations/evidence/governance-lifecycle-closure.md` (separate GRS-002 operating acceptance confirmed) |
| Inspect refreshed consumer evidence and the first proposed consumer lifecycle case | `docs/operations/reference-runs/2026-09-13-consumer-revalidation.md`, `docs/operations/evidence/consumer-lifecycle-operation-readiness.md` (roles/evidence scope confirmed; separate operating acceptance pending) |
| Prepare CLG-06.3 DevSecOps/architecture input candidates | `docs/operations/evidence/governance-lifecycle-input-candidates.md`, `scripts/prepare_lifecycle_devsecops_candidates.py`, `scripts/prepare_lifecycle_architecture_candidates.py` (unverified declarations; no lifecycle intake) |
| Decide the next live CLG pilot step | `docs/operations/evidence/governance-lifecycle-live-decision-brief.md` (pilot roles and limited operating acceptance confirmed) |
| Inspect confirmed CLG pilot roles and disabled live profile | `docs/operations/evidence/governance-lifecycle-live-preparation.md`, `model/governance/lifecycle/live-pilot/` (appointment is not personal runtime consent) |
| Verify an explicit Self-Security run before live admission | `docs/operations/evidence/governance-lifecycle-live-evidence-preflight.md`, `scripts/preflight_lifecycle_live_evidence.py` (read-only capture and offline replay; no acceptance) |
| Retain and replay pilot intake under confirmed operating values | `docs/operations/evidence/governance-lifecycle-durable-pilot-intake.md`, `scripts/intake_lifecycle_pilot_run.py` (durable validation receipts; no live activation) |
| Verify the personal GitHub channel probe | `docs/operations/evidence/governance-lifecycle-personal-channel.md`, `scripts/check_lifecycle_personal_channel.py` (personal statement required; no lifecycle authorization) |
| Validate action-specific GitHub consent | `docs/operations/evidence/governance-lifecycle-action-consent.md`, `scripts/intake_lifecycle_pilot_action.py` (pilot eligibility; effective LD-07 gates official publication) |
| Read the complete technical function inventory | `docs/operations/guides/repository-technical-function-inventory.md` |
| Understand and review post-merge documentation proposals | `docs/operations/guides/documentation-after-merge.md`, `.github/workflows/documentation-refresh.yml`, `scripts/reconcile_documentation_after_merge.py` |
| Review the authorized scope of post-merge documentation maintenance | `docs/governance/change-requests/GCR-2026-137-post-merge-documentation-refresh.md` |
| Inspect the accepted live pilot state | `docs/operations/status/governance-lifecycle-current-state.md`, `status/governance-lifecycle-live.json` |
| Inspect or operate the GitHub pilot after LD-07 | `docs/operations/evidence/governance-lifecycle-live-operation.md`, `scripts/run_lifecycle_pilot_update.py` (personal acceptance captured and merged; manual report-only pilot) |
| Open CLG-06.2 read-only scenario viewer | `docs/operations/evidence/governance-lifecycle-viewer.md`, `scripts/generate_governance_lifecycle_viewer.py` (synthetic; separate from official status) |
| Inspect CLG-06.1 synthetic scenario metrics | `docs/operations/evidence/governance-lifecycle-overview.md`, `scripts/generate_governance_lifecycle_overview.py` (separate histories; no portfolio totals) |
| Inspect CLG-05 synthetic exceptions | `docs/operations/evidence/governance-lifecycle-exceptions.md`, `scripts/generate_governance_lifecycle_exceptions.py` (observation coverage; no live waiver authority) |
| Audit the current documentation structure after migrations | `docs/operations/planning/document-structure-audit.md` |
| Understand organisational DevSecOps governance responsibilities | `docs/governance/devsecops-governance-organisational-role-model.md` |
| Understand source update impact | `generated/reports/governance-change-impact.md` |
| Review the harmonized standards-requirements candidate | `docs/governance/review-packets/CISO-REQ-SRC-001/README.md`, `docs/governance/review-packets/CISO-REQ-SRC-001/harmonized-requirements-candidate.md`, `docs/governance/review-packets/CISO-REQ-SRC-001/ciso-review-brief.md`, `model/requirements/harmonized-devsecops-requirements.yaml`, `model/traceability/harmonized-requirements-to-maturity-levels.yaml`, `generated/reports/harmonized-requirements-coverage.md`, `generated/reports/harmonized-requirements-maturity.md` |
| Assess architecture source replacements | `generated/reports/architecture-source-replacement-assessment.md` |
| Route reviews by role | `docs/governance/governance-roles-and-agent-profiles.md` |
| Use model-neutral agent contracts | `.agents/roles/`, `.agents/routing/governance-agent-routing.yaml`, `.agents/skills/`, `docs/operations/agents/agent-system-usage.md` |
| Use Codex agent adapters | `.codex/agents/`, `.github/codex/prompts/`, `docs/operations/agents/agent-system-usage.md` |
| Check deterministic agent routing | `docs/operations/agents/agent-harness-usage.md`, `tests/agent_harness/` |
| Run revision-bound reviews, export receipts and interpret PR metadata | `docs/operations/agents/how-to-run-agent-review.md`, `docs/operations/agents/agent-review-tooling-reference.md` |
| Prepare optional read-only execution or grade synthetic review answers offline | `docs/operations/agents/agent-review-tooling-reference.md`, `.agents/execution-contract.yaml`, `.agents/evaluations/` |
| Inspect Codex model selection and its measured limitations | `docs/operations/agents/agent-system-usage.md`, `docs/operations/reference-runs/2026-09-12-gpt6-agent-evaluation.md` |
| Inspect agent usage | `docs/operations/agents/agent-usage-snapshot-latest.md`, `generated/agent-usage/agent-usage-summary.json` |
| Find actual L1 tests, SBOMs, scans, Container Security viewer and intake | `docs/operations/evidence/l1-measured-evidence-ha-cpswms.md` |
| Understand DevSecOps baseline releases | `docs/releases/index.md`, `docs/releases/l1-baseline-v1.2.0.md` |
| Understand architecture baseline releases | `docs/releases/architecture-baseline-l1-v0.1.0.md` |
| Understand intake and viewer | `docs/operations/evidence/governance-result-intake-and-viewer-usage.md` |
| Operate Evidence- und Governance-Hardening | `docs/operations/guides/evidence-and-governance-hardening-guide.md` |
| Assess governance repository self-security | `docs/operations/security/governance-repository-self-security.md`, `model/controls/governance-repository-security.yaml`, `scripts/assess_governance_repository_security.py`, `generated/reports/governance-repository-security.md` |
| Export and review the repository dependency SBOM | `docs/operations/security/repository-sbom-and-vulnerability-management.md`, `scripts/export_repository_sbom.py`, `.github/workflows/repository-sbom.yml`, `docs/governance/change-requests/GCR-2026-107-repository-sbom-export.md` |
| Verify governance release-tag integrity | `model/governance/release-signing-policy.yaml`, `releases/release-tag-integrity.json`, `scripts/lib/release_integrity.py` |
| Review the 17 September repository hardening and Bitbucket/Bamboo portability | `docs/operations/security/repository-security-hardening-2026-09-17.md`, `docs/governance/change-requests/GCR-2026-094-governance-repository-security-hardening.md` |
| Review executable-code security and the 18 September intake hardening | `docs/operations/security/repository-code-security-assessment-2026-09-18.md`, `docs/governance/change-requests/GCR-2026-096-repository-code-security-hardening.md` |
| Operate the vulnerability-scan collector pilot | `docs/operations/evidence/vulnerability-scan-collector-usage.md`, `scripts/collect_vulnerability_scan_evidence.py` |
| Understand portfolio adoption reporting | `docs/operations/status/portfolio-adoption-reporting.md`, `governance/portfolio-adoption-reporting.yaml` |
| Inspect external consumer pilot remediation and results | `docs/governance/change-requests/GCR-2026-114-external-consumer-pilot-intake-remediation.md`, `docs/operations/status/external-consumer-validation-pilot-2026-10-05.md` (private exploratory pilot; no official admission) |
| Implement Bamboo 12.1.9 adapter | `docs/operations/adapters/bitbucket-bamboo-governance-adapter.md`, `pipeline-baseline/templates/bamboo/bamboo-specs/bamboo.yaml` |
| Understand report-only versus blocking | `docs/operations/processes/operational-governance-enforcement-options.md` |
| Work as an AI agent | `AGENTS.md`, `docs/operations/ai-working-rules.md` |

## Foundation Documents

The foundation documents define the strategic and architectural context for this repository. They are helpful before changing governance structure, agent behavior, adapter strategy, or portfolio-level reporting.

| File | Purpose |
|---|---|
| `docs/foundation/01_VISION.md` | Engineering Governance Runtime vision and target outcome |
| `docs/foundation/02_CONSTITUTION.md` | Stable operating principles and decision constraints |
| `docs/foundation/03_ARCHITECTURE_PRINCIPLES.md` | Architecture principles for capability separation and runtime governance |
| `docs/foundation/04_REFERENCE_ARCHITECTURE.md` | Reference architecture context for the repository structure |
| `docs/foundation/05_CURRENT_DIRECTION.md` | Current milestone direction and explicit scope boundaries |
| `docs/foundation/06_KEYNOTE_STORY.md` | Narrative explanation for stakeholder communication |
| `docs/foundation/07_AI_CONTEXT.md` | AI-agent working context and decision priorities |
| `docs/foundation/08_GLOSSARY.md` | Shared terminology |

These files are architectural and strategic guardrails. They do not replace approved policy, directive, standards, released baselines, source-document registers, or recorded governance decisions.

## Source Documents

Use the [source-document dependency map](operations/guides/source-document-dependency-map.md)
to distinguish effective model inputs, approved sources with unresolved requirement
decisions, and review or candidate material.

The sanitized source requirement extracts live in:

```text
docs/governance/source-documents/
```

The original source documents are withheld from the repository. The files below provide bounded requirement content for intake review and traceability.

Current registered requirement extracts:

| Source document | Main derived area |
|---|---|
| `DSCB-STD-SRC-001.requirements.md` | DevSecOps controls and OPA policy candidates |
| `PRA-STD-SRC-001.requirements.md` | Platform levels and pipeline baseline |
| `DEVSECOPS-DIR-SRC-001.requirements.md` | Governance directive |
| `DEVSECOPS-POL-SRC-001.requirements.md` | Governance policy |
| `ARCH-SDD-SRC-001.requirements.md` | Architecture runtime governance |

When adding or changing derived governance artifacts, update or validate lineage:

```bash
python3 scripts/generate_source_lineage_report.py
python3 scripts/validate_governance_repo.py
```

Use the lifecycle and template for future updates:

```text
docs/governance/governance-change-lifecycle.md
docs/governance/change-requests/TEMPLATE.md
model/documents/source-document-register.yaml
```

For new documents that may match or replace an existing source, register them as `candidate` first and use `candidate_replacement_for` plus `similarity_assessment`.

Use role profiles to decide who should review the change:

```text
docs/governance/governance-roles-and-agent-profiles.md
```

Generate the current source-document impact overview:

```bash
python3 scripts/generate_governance_change_impact_report.py
```

Generate the architecture source replacement assessment:

```bash
python3 scripts/generate_architecture_source_replacement_assessment.py
```

For human intake reviews, use the operating model and review packet:

```text
docs/operations/processes/source-document-intake-review-operating-model.md
generated/reports/source-document-intake-status.md
generated/reports/source-document-intake-review-briefs.md
generated/reports/source-document-requirement-delta.md
```

The Intake Agent may prepare evidence and options, but the final source
decision must be recorded by a human reviewer in a governance change request.

## DevSecOps Governance Map

| Concern | Files |
|---|---|
| Controls | `model/controls/dscb-l1.yaml`, `model/controls/dscb-l2.yaml`, `model/controls/dscb-l3.yaml`, `model/controls/dscb-gov.yaml` |
| Coverage | `model/controls/control-coverage.yaml`, `generated/reports/control-coverage-report.md` |
| Evidence | `model/evidence/evidence-types.yaml`, `model/evidence/evidence-trust-model.yaml`, `model/evidence/evidence-freshness-policies.yaml`, `model/evidence/evidence-collector-contract.yaml`, `docs/operations/evidence/governance-evidence-contract.md`, `docs/operations/evidence/evidence-trust-model.md`, `docs/operations/evidence/evidence-collector-contract.md`, `docs/operations/evidence/vulnerability-scan-collector-usage.md` |
| Pipeline placement | `pipeline-baseline/` |
| OPA policies | `policies/opa/*` |
| Published patch baseline | `releases/l1/v1.2.1/`, `docs/releases/l1-baseline-v1.2.1.md` |
| Reusable workflow | `.github/workflows/devsecops-baseline-l1-v1.2.1.yml` |
| Previous baseline | `releases/l1/v1.2.0/`, `docs/releases/l1-baseline-v1.2.0.md` |
| Previous reusable workflow | `.github/workflows/devsecops-baseline-l1-v1.2.0.yml` |
| Retained consumer baseline | `releases/l1/v1.1.3/`, `docs/releases/l1-baseline-v1.1.3.md` |

Typical validation:

```bash
python3 scripts/validate_governance_repo.py
python3 -m unittest discover -s tests
```

## Architecture Runtime Governance Map

| Concern | Files |
|---|---|
| Runtime addendum | `docs/governance/architecture/runtime-governance-addendum.md` |
| Runtime transformation | `docs/governance/architecture/runtime-governance-transformation.md` |
| Levels | `architecture/arch-l1.yaml`, `architecture/arch-l2.yaml`, `architecture/arch-l3.yaml`, `architecture/arch-gov.yaml` |
| Markers | `architecture/quality-markers.yaml` |
| Guardrails and gates | `architecture/guardrails.yaml`, `architecture/review-gates.yaml` |
| Remediation | `architecture/remediation-actions.yaml` |
| OPA policies | `policies/opa/architecture_*.rego` |
| Schemas | `schemas/architecture-release-candidate.schema.json`, `schemas/app-architecture-evidence.schema.json` |
| Current release | `releases/architecture/l1/v0.1.0/`, `docs/releases/architecture-baseline-l1-v0.1.0.md` |
| Reusable workflow | `.github/workflows/architecture-baseline-l1-v0.1.0.yml` |

Typical validation:

```bash
python3 scripts/validate_runtime_governance.py
python3 -m unittest discover -s tests
```

## Viewer And Status Map

| Concern | Files |
|---|---|
| DevSecOps result index | `status/repository-results-index.json` |
| DevSecOps result history | `status/results/` |
| Architecture result index | `status/architecture-results-index.json` |
| Architecture result history | `status/architecture-results/` |
| Measured L1 control assessment | `scripts/intake_measured_l1.py`, `scripts/lib/measured_l1.py`, `schemas/measured-l1-assessment.schema.json`, `status/measured-l1-results/`; viewer repository tab `l1` |
| L1 control evidence assurance | `model/evidence/control-evidence-assurance-profile.yaml`, `scripts/lib/control_evidence_assurance.py`, `schemas/control-evidence-assurance.schema.json`, `status/control-evidence-assurance/`; viewer repository tabs `l1` and `trust` |
| Staging deployment evidence | `scripts/intake_staging_deployment_evidence.py`, `scripts/lib/staging_deployment.py`, `schemas/staging-deployment-result.schema.json`, `status/staging-deployment-results/`; viewer repository tab `staging` |
| Consolidated L1 assessment | `scripts/lib/consolidated_l1.py`, `schemas/consolidated-l1-assessment.schema.json`, `status/consolidated-l1-results/`; exact-run overlay of staging controls 013/014/016 in viewer tab `l1` |
| Repository Security viewer projection | `generated/reports/governance-repository-security.json`, `schemas/governance-repository-security-report.schema.json`, `scripts/lib/viewer_app.py`; viewer route `#repository-security` |
| Repository Security automatic refresh | `.github/workflows/refresh-governance-repository-security.yml`, `scripts/publish_self_security_refresh.py`; material changes only, one reviewed PR, no direct main write |
| Viewer application | `apps/governance-viewer/`, `scripts/lib/viewer_app.py`, `scripts/lib/viewer_technical.py`, `generated/viewer/app/index.html`; guide: `docs/operations/guides/governance-viewer-app.md` |
| Viewer generator | `scripts/generate_status_viewer.py` |
| Viewer outputs | `generated/viewer/app/index.html` (primary application), `generated/viewer/status-viewer.html` (technical fallback) |
| Intake docs | `docs/operations/evidence/governance-result-intake-and-viewer-usage.md` |
| Vulnerability collector guide | `docs/operations/evidence/vulnerability-scan-collector-usage.md` |
| Typed evidence result index | `status/typed-evidence-results-index.json` |
| Typed evidence result history | `status/typed-evidence-results/` |
| Typed evidence intake | `scripts/intake_evidence_trust_github_actions_run.py`; five-image ha-CPsWMS vulnerability and SBOM profiles: `scripts/intake_ha_container_trust.py`, `scripts/lib/container_typed_evidence.py` |
| Governance graph schema | `schemas/governance-graph.schema.json` |
| Governance graph generator | `scripts/generate_governance_graph.py` |
| Governance graph output | `generated/graph/governance-graph.json` |
| Governance graph guide | `docs/operations/status/governance-intelligence-graph-viewer.md` |
| Append-only ledger and replay logic | `scripts/lib/result_ledger.py` |
| Replay triage guide | `docs/operations/evidence/replay-triage.md` |
| Replay triage generator and output | `scripts/generate_replay_triage_report.py`, `generated/reports/replay-triage.json` |
| Intake conflict quarantine | `status/intake-conflicts/` |
| Intake conflict schema | `schemas/intake-conflict.schema.json` |
| Agent usage snapshot | `docs/operations/agents/agent-usage-snapshot-latest.md` |
| Agent usage summary | `generated/agent-usage/agent-usage-summary.json` |
| Evidence collection attempts | `schemas/evidence-collection-attempt.schema.json`, `scripts/record_collection_attempt.py`, `status/collection-attempts/` |
| Intake operation telemetry | `docs/operations/evidence/intake-operation-telemetry.md`, `schemas/intake-operation-event.schema.json`, `scripts/record_intake_event.py`, `status/intake-events/` |
| Intake Health projection | `docs/operations/evidence/intake-health-projection.md`, `schemas/intake-health.schema.json`, `scripts/generate_intake_health.py`, `status/intake-health.json` |
| Multi-consumer readiness | `docs/operations/status/multi-consumer-readiness.md`, `schemas/multi-consumer-readiness.schema.json`, `scripts/generate_multi_consumer_readiness.py`, `generated/reports/multi-consumer-readiness.json` |
| Blocking readiness | `docs/operations/status/blocking-readiness.md`, `model/enforcement/blocking-readiness.yaml`, `scripts/generate_blocking_readiness.py`, `generated/reports/blocking-readiness.json` |
| Blocking mode alignment | `docs/operations/status/blocking-mode-alignment.md`, `model/enforcement/blocking-mode-alignment.yaml`, `scripts/generate_blocking_mode_alignment.py`, `generated/reports/blocking-mode-alignment.json` |
| Evidence attestation pilot | `docs/operations/evidence/evidence-attestation-pilot.md`, `model/evidence/evidence-trust-roots.yaml`, `schemas/evidence-attestation.schema.json`, `scripts/verify_evidence_attestation.py`, `generated/reports/evidence-attestation-pilot.json` |
| Controlled collection retry | `.github/workflows/retry-collection-attempt.yml`, `scripts/prepare_collection_attempt_retry.py` |
| Collection-attempt lifecycle projection | `scripts/generate_status_viewer.py`, both viewer outputs |
| Evidence agent provenance | `schemas/evidence-agent-provenance.schema.json`, `scripts/record_evidence_agent_provenance.py`, `scripts/validate_evidence_agent_provenance.py`, `status/evidence-agent-provenance/` |

Regenerate viewer:

```bash
python3 scripts/generate_governance_graph.py
python3 scripts/generate_status_viewer.py
```

## Demo Map

| Demo need | File |
|---|---|
| Full end-to-end demo | `docs/demos/demo-end-to-end-governance.md` |
| Consumer typed-evidence demo | `docs/demos/demo-consumer-typed-evidence-trust.md` |
| Typed-evidence presentation guide | `docs/demos/presentation-guide-typed-evidence-trust-de.md` |
| Architecture-only demo | `docs/demos/demo-ha-cpswms-runtime-governance.md` |
| Architecture result explanation | `docs/demos/ha-cpswms-architecture-governance-results.md` |
| DevSecOps historical demo guide | `docs/demos/demo-guide-2026-07-02-ha-cpswms.md` |
| Viewer | `generated/viewer/app/index.html`; technical fallback: `generated/viewer/status-viewer.html` |

Accepted ha-CPsWMS governance mainline runs on 16 September 2026 (control
outcomes; the separate DevSecOps replay finding remains open):

| Domain | Run | Expected |
|---|---:|---|
| DevSecOps Baseline | `35131186298` | pass, `16/16` controls |
| Architecture Runtime Governance | `35131185047` | PASS, `4/4` gates |
| Measured L1 and typed evidence | `35241262722` | report-only; 58 tests, vulnerability/SBOM Trust and assurance for 16 controls |

## Release Map

| Domain | Current release | Key files |
|---|---|---|
| Repository adoption/operations | Publication readback on 15 November: v0.2.0 published; v0.3.0 prepared/unpublished | `docs/releases/index.md` |
| DevSecOps L1 | `l1-baseline-v1.2.1`; retained consumer pins remain separate | `docs/releases/l1-baseline-v1.2.1.md`, `releases/l1/v1.2.1/` |
| Architecture L1 | `architecture-baseline-l1-v0.1.0` | `docs/releases/architecture-baseline-l1-v0.1.0.md`, `releases/architecture/l1/v0.1.0/` |

When creating a new release, update:

- release docs
- technical release package
- checksums
- reusable workflow or template if applicable
- source lineage
- README and official entrypoints if the release becomes the recommended baseline

## Before Committing

Run:

```bash
./scripts/bootstrap_validation_env.sh
./scripts/validate_all.sh
git status --short
```

Commit only intentional files. Do not add `.DS_Store`.

Consumer operation implementation: `docs/operations/evidence/consumer-lifecycle-operation.md`, `scripts/run_consumer_lifecycle.py`, `status/governance-consumer-lifecycle.json`.
