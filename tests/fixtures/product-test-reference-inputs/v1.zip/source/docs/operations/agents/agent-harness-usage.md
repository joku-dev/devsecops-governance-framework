# Agent Harness Usage

## Purpose

The agent harness is a deterministic safety net for Codex governance-agent routing.

It does not call an LLM and does not grade free-text agent answers. It checks whether repository changes imply the expected governance roles, validations, release-impact classification, and safety invariants.

Model availability and answer quality require separate, explicitly requested
live evaluations. The [GPT-6 migration reference run](../reference-runs/2026-09-12-gpt6-agent-evaluation.md)
contains a bounded comparison; its calls are not part of this harness or CI.

## What It Covers

The harness currently covers:

- production path-to-agent routing, including Workbench, requirements and provider adapters
- staged, unstaged, renamed, deleted and untracked Git paths
- revision/source/index/contract binding of private review plans
- incomplete, skipped and stale reviews, required role outputs and final stewardship
- path traversal rejection and unknown role/skill contract failures
- path-to-agent routing for governance repository areas
- mandatory `repo-steward` selection for meaningful changes
- required validation commands per selected role
- scenario fixtures for common governance changes
- candidate source-document protection
- released baseline protection
- evidence context protection for non-mainline results
- receipt allowlisting, private output, retry idempotency and separate usage counts
- trusted-base PR metadata inspection and target/proposed contract requirements
- prepare-only execution, mocked provider failures/timeouts and final Steward ordering
- offline synthetic scoring, revision binding and supplied measurement validation

The execution tests mock provider processes; the evaluation tests use synthetic
answers and traces. These regressions do not exercise a live CLI/account or
establish measured model quality. See the [tooling reference](agent-review-tooling-reference.md)
for the production CLI/artifact map and score interpretation.

The role profile document remains the source of truth:

```text
docs/governance/governance-roles-and-agent-profiles.md
```

The model-neutral agent contracts live in:

```text
.agents/roles/
.agents/routing/governance-agent-routing.yaml
.agents/skills/
```

## Files

```text
tests/agent_harness/routing.py
tests/agent_harness/test_agent_contracts.py
tests/agent_harness/test_agent_routing.py
tests/agent_harness/test_agent_scenarios.py
tests/agent_harness/test_review_execution.py
tests/agent_harness/test_agent_receipts.py
tests/agent_harness/test_agent_review_status.py
tests/agent_harness/test_agent_execution.py
tests/agent_harness/test_agent_evaluation.py
tests/agent_harness/scenarios/*.json
tests/agent_harness/expected/*.expected.json
.agents/roles/*.yaml
.agents/routing/governance-agent-routing.yaml
.agents/skills/*/SKILL.md
```

## Run The Harness

Run only the harness:

```bash
python3 -m unittest discover -s tests/agent_harness
```

Run it with the full repository tests:

```bash
python3 -m unittest discover -s tests
```

The harness is intentionally local-only. It must not require network access, GitHub secrets, live Codex execution, or live LLM calls.

Use the deterministic dispatch CLI for day-to-day routing:

```bash
python3 scripts/dispatch_governance_agents.py --base-ref origin/main
```

For the end-to-end operator workflow around dispatch, role execution, validation, and commit readiness, read:

```text
docs/operations/agents/how-to-run-agent-review.md
```

The routing contract also reserves adapter paths for company CI/CD platforms such as Bamboo, Bitbucket, Jenkins, and GitLab. These paths route to neutral governance roles (`devsecops-baseline`, `release-manager`, and `repo-steward`) rather than to GitHub- or Codex-specific behavior.

## Add A Scenario

1. Add a scenario JSON file under:

```text
tests/agent_harness/scenarios/
```

2. Add the matching expected result under:

```text
tests/agent_harness/expected/
```

The expected file name must match this pattern:

```text
<scenario-name>.expected.json
```

3. Include at least:

```json
{
  "selected_agents": ["repo-steward"],
  "required_validations": ["git diff --check"],
  "release_impact": "none",
  "forbidden_changes": [],
  "commit_readiness": "requires_review"
}
```

4. Run:

```bash
python3 -m unittest discover -s tests/agent_harness
```

## Interpret Failures

A routing failure means the changed paths no longer map to the expected review roles.

A required-validation failure means a selected role does not demand a validation command expected by the scenario.

A release-impact failure means a scenario may silently change release or baseline semantics.

A candidate-protection failure means a candidate source document may have produced derived governance artifacts too early.

An evidence-context failure means a branch, pull request, or manual run may be treated like an official mainline result.

## Extend Routing

Update routing only when the repository structure or governance ownership model changes:

```text
.agents/routing/governance-agent-routing.yaml
```

Keep changes small and add or update a scenario for every new routing rule.
`tests/agent_harness/routing.py` only imports the production implementation.

The router adds every matching prefix's roles. Architecture OPA therefore keeps
Policy-as-Code and Release Manager while adding Architecture Runtime Governance.
Viewer Python projections, result intake/index scripts, lifecycle implementations,
current-main artifacts, demo runbooks and operational status pages have explicit
domain routing. An unknown functional path still reports the Analyst fallback;
it does not silently claim that domain classification is complete.

## Relationship To Existing Validators

The harness does not replace:

```bash
opa check policies/opa
python3 scripts/validate_runtime_governance.py
python3 scripts/validate_governance_repo.py
```

It tells maintainers which of those validations should be requested by the selected governance roles.
