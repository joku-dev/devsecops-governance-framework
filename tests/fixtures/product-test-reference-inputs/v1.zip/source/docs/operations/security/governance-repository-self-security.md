# Governance Repository Self-Security

## Purpose

This operating guide protects the repository that defines, evaluates, and
distributes governance. Consumer results are not sufficient evidence that the
governance authority itself is trustworthy.

The self-security profile is defined in:

```text
model/controls/governance-repository-security.yaml
```

The live assessment is produced by:

```text
scripts/assess_governance_repository_security.py
```

## Trust Boundary

Repository content cannot be its own complete root of trust. The assessment
therefore combines two control planes:

1. versioned repository controls such as CODEOWNERS, dependency configuration,
   workflows, tests, release metadata, and assessment logic;
2. externally enforced GitHub settings such as branch rules, required checks,
   security features, workflow restrictions, and signature requirements.

If the GitHub API cannot supply a required observation, the criterion fails
visibly. Missing evidence is never interpreted as a pass.

## Profile Scope

The initial report-only profile evaluates:

- default-branch protection;
- pull-request and approval requirements;
- required Governance CI;
- force-push and deletion protection;
- signed-change requirements;
- secret scanning and push protection;
- dependency security and CodeQL;
- private vulnerability reporting;
- full-SHA pinning for third-party Actions;
- restriction to approved GitHub Action sources;
- workflow permission restrictions;
- explicit ownership of critical paths;
- direct automated writes to `main`;
- cryptographically verified release tags.

## Run Locally

Authenticate the GitHub CLI, fetch release tags, and run:

```bash
GH_TOKEN="$(gh auth token)" \
python3 scripts/assess_governance_repository_security.py
```

Outputs:

```text
generated/reports/governance-repository-security.json
generated/reports/governance-repository-security.md
```

Release-tag verification loads
`model/governance/release-signing-policy.yaml`. Directly signed tags are checked
against its active SSH signers. The fixed historical set is checked against the
signature on `releases/release-tag-integrity.json`, exact tag-object and target
commit identities, and the bound release-package checksums. The historical mode
is a retrospective integrity statement and is shown separately from a direct
publication-time tag signature. Every new release tag requires a direct trusted
signature.

Der Governance Workspace zeigt den schema-validierten Stand zusätzlich im
eigenen Bereich [Repository Security](https://joku-dev.github.io/devsecops-governance-framework/generated/viewer/app/index.html#repository-security).
Die Ansicht übernimmt Gesamtstatus, Kriterien, Beobachtungsdetails und
dokumentierte Maßnahmen aus dem gespeicherten Bericht. Sie fragt GitHub nicht
live ab und ändert keine Schutzregel.

The required-check workflow runs the same assessment for pull requests, pushes
to `main`, and manual dispatch. A separate trusted refresh workflow runs daily
at `04:31 UTC` and on manual dispatch. Findings remain report-only.

## Automatic Versioned Refresh

`.github/workflows/refresh-governance-repository-security.yml` collects a fresh
live observation from protected `main`, uploads the point-in-time report as a
workflow artifact, regenerates the Governance Workspace projection, and invokes
`scripts/publish_self_security_refresh.py`. It installs the locked Python
validation dependencies and the pinned OPA `1.18.2` validator before running
the repository and workflow-contract checks.

The live assessment uses the dedicated repository secret
`GH_SELF_SECURITY_READ_TOKEN` because the default workflow token cannot read
all administrative repository and Actions settings. Configure it as a
fine-grained personal access token with access only to this repository and the
repository permission **Administration: Read-only**. Metadata read access is
included by GitHub; the assessment requires no write permission. Do not reuse
the result-intake token for this purpose.

The secret is exposed only to the assessment step; PR publication and check
dispatch continue to use the scoped workflow token. If the secret is
unavailable the workflow can fall back to the workflow token for collection,
but any resulting GitHub API error makes versioned publication fail closed. The
incomplete point-in-time report remains available as a workflow artifact for
diagnosis.

API errors record the failing endpoint so token-scope problems remain
diagnosable. Two legacy branch-protection endpoints may return `404` when an
effective repository ruleset protects `main`. Those specific responses are
non-blocking only when the same observation confirms effective branch
protection through the ruleset API. Authentication failures, authorization
failures, invalid responses, and every other API error remain blocking.

The publisher compares security-relevant JSON after removing only the top-level
and nested observation timestamps. If all other values are unchanged, it does
not create a commit or update a pull request. A changed criterion, observation,
summary, remediation step, repository setting, workflow inventory, or
release-tag result is material. Blocking GitHub API errors prevent versioned
publication instead of being interpreted as a repository-setting regression.

Material changes are restricted to:

```text
generated/reports/governance-repository-security.json
generated/reports/governance-repository-security.md
```

`generated/viewer/app/data.json` remains an ignored build artifact. The refresh
builds and validates that projection before publication; after a report merge,
the Pages workflow regenerates it from the versioned report. It is never added
to the status pull request.

They are proposed through one branch and at most one open pull request:

```text
automation/self-security-refresh
```

If that pull request already exists, the workflow merges the latest protected
`main` into its branch without force-pushing, writes the newly generated files,
and updates the same review. An unresolved merge conflict, a stale branch
without an open pull request, a symlink, or any non-allowlisted source change
fails closed.

The workflow explicitly dispatches Governance CI, CodeQL, Self-Security,
Dependency Review, and Consumer Lifecycle Guard for the automation branch.
These dispatches provide immediate validation evidence. Because GitHub does not
associate manually dispatched checks with a bot-created pull request, a
maintainer must also approve the five pending PR-context workflow runs in the
Actions UI before the protected-branch checks are satisfied. The workflow never
approves those runs, approves or merges its own pull request, changes GitHub
settings, or pushes to `main`. Merging the reviewed refresh updates the
versioned report; the Pages build then updates the Viewer. The point-in-time
artifact remains available even when no material change is proposed.

## Current Activation State

Documentation observation on 3 October 2026 (source `46b33429`): main assessment
[run `37118684212`](https://github.com/joku-dev/devsecops-governance-framework/actions/runs/37118684212)
reported **8 pass / 8 fail (not evidenced)** at `2026-10-03T11:08:18Z`.
The live ruleset requires one approval, not two, and no signed-commit rule.
Other findings include unavailable security settings and HTTP 403 responses for
administrative observation. Missing values are not evidence that those features
are disabled. A successful report-only assessment job is not a clean security result.
The versioned JSON/Markdown report still observes 19 September; use the latest
workflow artifact and its API errors for a new live assessment. The following
activation and hardening statements are dated historical observations.

As of 2026-09-18, GitHub secret scanning, secret push protection, dependency
alerts, automated security updates, and private vulnerability reporting are
enabled. The versioned change adds
Dependabot configuration, CodeQL, dependency review, full-SHA Action pinning,
expanded CODEOWNERS, and the report-only self-security workflow.

The initial assessment recorded 7 passing and 9 failing criteria. Refresh run
`35315432116` and reviewed status PR #140 later recorded 13 passing and 3
failing criteria. GCR-2026-102 verifies release integrity; the retained September
assessment records 14 passing and 2 failing criteria (`GRS-002`, `GRS-005`). Consult the
latest workflow assessment artifact for the current live settings; the
versioned report is a dated observation, not a general security certification.

GCR-2026-051 authorized the implemented writer migration: four operational writers now propose
review PRs using scope-specific allowlists and immutable historical evidence.
The desired GitHub configuration is versioned in `.github/main-ruleset.json`.
The live ruleset was verified active on 9 September 2026 after the migration:
one required approving review, three strict required checks, resolved threads,
stale approval dismissal, no force push/deletion and no bypass. PR #60 exercised
the real intake publication path. PR #61 used a separately authorized temporary
review exception and restored the one-review rule immediately afterward; that
exception is not a standing permission. See the
[operations handbook](../guides/governance-repository-operations-handbook.md).

## Administrative Observation On 11 September 2026

The restored protection still requires one review, strict checks and no standing
bypass. Central PRs #64 and #67 used separately authorized exceptions that were
restored and audited immediately after their merges.

The 11 September authenticated assessment confirmed 12 of 16 criteria and four gaps:
`GRS-005` signed-change enforcement, `GRS-010` repository-level SHA-pinning
requirements, `GRS-014` signatures on the three historical release tags and
`GRS-016` restriction of Actions sources. All active workflow references are
already SHA-pinned. Secret scanning, push protection, Dependabot security
updates and read-only default workflow permissions were verified enabled.

The scheduled token cannot observe every administrative setting. Its unknown
values are not proof that a setting is disabled. Preserve those observation
limits and read the [current platform state](../status/current-governance-platform-state.md)
for the dated report context. GCR-2026-102 subsequently introduced direct
verification and a signed retrospective manifest without rewriting those tags.

## Hardening Update On 17 September 2026

GCR-2026-094 activated repository-level full-SHA enforcement and selected
Action sources. GitHub-owned Actions and the explicitly required
`open-policy-agent/setup-opa` Action are allowed. Dependency Review is now a
required main check, CODEOWNER review and last-push approval are active, and
the versioned ruleset includes all five effective checks.

The evaluator now recognizes every reviewed PR publisher and no longer reports
the consumer lifecycle, lifecycle pilot or typed-evidence assurance publishers
as direct `main` writers. Intake, operations, portfolio, retry and documentation
publication installations use reviewed hash locks. Governance CI,
Self-Security and the local bootstrap retain exact version pins until a new
personal lifecycle operating-acceptance revision authorizes their manifest
change.

The GRS-002 target has been raised to two independent approvals plus CODEOWNER
and last-push approval. Only one human collaborator currently exists, so the
live approval count remains one and GRS-002 is an explicit open finding. Signed
changes, signer rotation/recovery, a short-lived GitHub App collector identity
and off-site recovery remain separate prerequisites. See the complete
[hardening record](repository-security-hardening-2026-09-17.md).

The accepted lifecycle source profile still pins Self-Security `0.2.0` and its
earlier evaluator. Historical receipts remain immutable. A new lifecycle
`observe` operation for `0.3.0` requires a new preparation/operating revision
and personal acceptance first.

## Executable-Code Review On 18 September 2026

GCR-2026-096 independently reviewed Python, maintained JavaScript, dependencies
and active workflows. The change closes cross-origin bearer-token forwarding
in GitHub artifact downloads, replaces unrestricted ZIP extraction with one
bounded fail-closed implementation, adds explicit XML input limits and extends
CodeQL to JavaScript. See the dated
[code security assessment](repository-code-security-assessment-2026-09-18.md)
for findings, scanner evidence and residual limits. This code review complements
the live repository-control profile; it does not turn the report-only
Self-Security result into a certification.

GCR-2026-098 adds the automatic reviewed refresh described above. The daily
schedule moved from the read-only required-check workflow to the dedicated
writer so exactly one scheduled assessment performs publication logic. Pull
requests and pushes to `main` continue to run the read-only required check.

## Safe Activation Sequence

The sequence below explains activation dependencies. Steps 1–5 are implemented
on the central repository as of 9 September 2026; steps 6–8 remain separate
hardening decisions. When setting up a replacement repository, verify each
step instead of assuming versioned configuration has activated live settings:

1. merge the self-security profile, evaluator, SHA-pinned Actions, Dependabot,
   CodeQL, dependency review, CODEOWNERS expansion, and security policy;
2. enable secret scanning, push protection, dependency alerts, and automated
   security updates;
3. observe Governance CI, CodeQL, dependency review, and self-security on
   `main`;
4. replace direct intake and portfolio pushes with a reviewed bot-PR path or a
   separately protected evidence store;
5. apply the versioned `main` ruleset: one approving review, stale approval
   dismissal, resolved conversations, an up-to-date branch, and required
   `validate-and-report`, `Analyze Python`, and `Governance Repository Security`
   checks from GitHub Actions; prohibit deletion and force push, with no bypass;
6. restrict Actions to approved publishers and require full commit-SHA pinning;
7. establish two independent reviewers and commit signing; retain direct tag
   signing for every new baseline and public-adoption release;
8. after a successful observation period and accountable approval, consider
   making selected self-security criteria blocking.

Do not activate step 5 before step 4. First merge the workflow migration and
enable Actions PR creation while preserving read-only default token permissions.
Exercise a real intake, verify that it opens a PR without moving main, and check
the three explicitly dispatched validations. Test the proposed rules on a
disposable branch before applying them to main. Read back the effective rules
for main and rerun the live assessment after activation.

There is no automatic approval, merge, or administrator bypass. A maintainer can
review bot-authored PRs; a maintainer-authored PR needs another authorized person.
At the 17 September observation only `joku-dev` is a collaborator, so independent reviewer
onboarding remains necessary for those PRs. Do not impersonate that reviewer or
weaken protection to complete a merge. Conflicting operational PRs need
reconciliation and regenerated projections before their final review.

## Normative And Operational Write Separation

The target state separates frequently changing evidence from normative
governance:

| Data class | Examples | Required write path |
|---|---|---|
| Normative governance | controls, policies, schemas, workflows, releases | reviewed PR with required owners and checks |
| Operational evidence | snapshots, intake events, conflicts, indexes | bot PR or separately protected evidence store |
| Generated presentation | reports, graph, viewer | deterministic regeneration from accepted source and evidence |

A bot that collects evidence must not be able to change normative governance.
GitHub token permissions alone are repository-wide, so path restrictions must
come from the write architecture and review flow rather than an assumption that
the bot will only stage intended paths.

## Enforcement Boundary

The current profile is `active_report_only`:

- it does not edit GitHub settings;
- it does not block pull requests;
- it does not authorize bypass;
- it does not change released baselines;
- it does not classify the governance authority as trusted when criteria fail.

Moving to blocking behavior requires a separate governance decision after the
automated-write migration and an observed stable period.
