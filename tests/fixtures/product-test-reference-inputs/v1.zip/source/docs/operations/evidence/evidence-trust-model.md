# Evidence Trust Model

## Status And Scope

Status: active, report-only model version 1.

The machine-readable source of truth is:

```text
model/evidence/evidence-trust-model.yaml
```

Its internal model schema is:

```text
schemas/evidence-trust-model.schema.json
```

This model improves how the repository reasons about evidence confidence. It
does not change the governance run input schema, existing result snapshots,
current latest-result selection, OPA policy behavior, released baselines, or
consumer workflow interfaces.

## Core Distinction

Evidence trust and governance outcome are separate decisions.

- Trust answers whether evidence identity, bytes, origin, age, custody, and
  authenticity were verified.
- Governance evaluation answers whether the evidence satisfies controls,
  architecture gates, thresholds, approvals, and exceptions.

A trusted report may contain governance findings. A passing report may remain
unverified. Neither value may be inferred from the other.

## Current-State Assessment

### DevSecOps Intake

The GitHub Actions intake records:

- repository, branch, commit, workflow run, event, status, and baseline
- artifact names and sizes
- SHA-256 for the downloaded archive, control evaluation report, and
  governance run input when present
- workflow run attempt and the authoritative artifact download URI
- initial download and extract-and-hash custody steps
- the downstream run URL

The central verifier independently recomputes captured-subject digests. For
DevSecOps result intake it also resolves the baseline from the producer run's
tagged `referenced_workflows` entry and immutable workflow SHA, checks that the
selected baseline agrees with that entry, validates the recorded download and
extract-and-hash custody steps, and evaluates freshness and replay. It derives
`provenance_verified` only when every check required by the model passes.
Missing or inconsistent provenance data prevents promotion and remains visible
as a failed or unevaluated Trust check. These checks remain report-only.

### Architecture Intake

The architecture intake records:

- repository, branch, commit, workflow run, event, status, and architecture
  baseline
- normalized evidence-presence flags and gate results
- the downstream run URL
- SHA-256 for the downloaded archive, architecture report, and release input
- workflow run attempt and initial custody steps

These fields are additive. Existing architecture snapshots remain valid and are
not rewritten.

### Shared Verification State

Both intake paths record a named verifier, verification timestamp, and
per-check results. Replay and freshness are evaluated by the shared verifier.
Architecture intake does not yet resolve its baseline from a pinned producer
workflow reference, so it cannot be promoted to `provenance_verified` by this
change. The remaining capabilities are:

- a normalized snapshot digest and transformation record
- production-approved issuer and attestation verification
- pinned architecture-baseline resolution from authoritative run metadata

Existing snapshots remain valid historical evidence and are not retroactively
promoted. Without an explicit trust assessment, their model default is
`unverified`.

### ha-CPsWMS Container Evidence

The fixed five-image vulnerability and SBOM intake has the additional
checks needed to derive `provenance_verified` on a newly captured snapshot.
When the evidence producer run itself references the tagged L1 reusable
workflow, the central verifier resolves the declared baseline against that
run's GitHub `referenced_workflows` entry and immutable workflow commit. The
ha-CPsWMS measured-evidence workflow is a separate local workflow, so its
`referenced_workflows` list is empty. For that profile, the verifier instead
requires exactly one successful `DevSecOps Baseline` push run on protected
`main` for the same repository and exact source commit. The verifier resolves
the report's declared baseline against that paired run's tagged L1 reusable
workflow reference and immutable workflow commit. Missing, failed, ambiguous,
manual, cross-branch, or different-commit baseline runs prevent promotion.
The paired run identity and workflow reference are recorded in the Trust
observations. The verifier also records a custody digest over all six artifact
archives and a normalized digest over the typed subjects and observations. Its
transformation list covers download, archive verification, selected-member
extraction, subject-hash verification, and normalization. Replay is evaluated
after central verification; the level advances only if replay and every other
rank-2 check pass.

This applies only to new evidence captured by the central ha-CPsWMS collector.
It does not relabel historical snapshots, change governance outcomes, establish
cryptographic attestation, or approve a release. The producer's scans remain
co-collected and report-only. A live status change requires a fresh successful
mainline run and its central intake after the verifier change is deployed.

## Trust Dimensions

| Dimension | Question |
|---|---|
| Identity | What evidence record and governed subject are being evaluated? |
| Integrity | Do recomputed digests match the collected evidence bytes? |
| Provenance | Which producer, workflow, run attempt, event, commit, and baseline created the evidence? |
| Authenticity | Did an approved issuer attest to the exact evidence subject? |
| Freshness | Is the evidence valid for the time and decision context in which it is used? |
| Replay resistance | Is this evidence unique to the claimed subject and run attempt? |
| Chain of custody | Can acquisition and every normalization step be traced by digest? |

Presence alone does not satisfy a dimension. A verifier must evaluate its
required claims and record the result.

## Trust Levels

| Rank | Level | Meaning | Explicit limitation |
|---:|---|---|---|
| 0 | `unverified` | Evidence is recorded without asserted verification. | Not sufficient for independent audit reliance or automated blocking. |
| 1 | `integrity_verified` | Subject identity exists and collected bytes match a verified digest. | Does not establish producer identity or authoritative provenance. |
| 2 | `provenance_verified` | Integrity, source run, commit, artifact binding, freshness, replay, and custody are verified. | Does not provide cryptographic issuer assurance. |
| 3 | `attested` | Provenance-verified evidence has a valid, subject-bound attestation from an approved issuer. | Does not imply a governance pass or authorize blocking by itself. |

Levels are monotone. A higher level includes every dimension and check required
by lower levels.

## Assignment Rules

The effective trust level is derived from the required checks in
`model/evidence/evidence-trust-model.yaml` after replay evaluation. Existing
snapshots are not retroactively promoted or downgraded.

The producer may provide claims and attestations, but it cannot self-declare a
trusted level. The verifier must:

1. resolve the authoritative workflow run
2. bind repository, commit, run attempt, artifact, and baseline
3. recompute and compare content digests
4. evaluate freshness and replay rules
5. record acquisition and transformation custody
6. validate attestation signature, issuer, and subject for `attested`

`unknown`, missing, skipped, and `not_evaluated` checks do not satisfy a trust
level.

## Additive Trust Capture Record

New automated intake snapshots include a normalized block. This abbreviated
view shows the trust state and capture categories; the linked example contains
the complete schema-valid record:

```json
{
  "trust": {
    "model_id": "evidence-trust-model-v1",
    "capture_phase": "additive_capture",
    "effective_level": "unverified",
    "assessment_status": "not_evaluated",
    "verifier": null,
    "verified_at": null,
    "checks": [],
    "capture": {
      "contract_id": "evidence-collector-contract",
      "contract_version": "0.1.0",
      "status": "collected",
      "enforcement": "report_only",
      "evidence_type": "governance_result",
      "governance_domain": "architecture",
      "collector": {
        "id": "central-governance-intake",
        "version": "0.1.0"
      },
      "produced_at": "2026-07-15T13:58:00Z",
      "captured_at": "2026-07-15T14:00:00Z",
      "source": {
        "provider": "github_actions",
        "repository_id": "joku-dev/ha-CPsWMS",
        "commit_id": "716c3cda4fa5cef7504ca7b3263f0cd1697b6e6c",
        "run_id": "29415015294",
        "run_attempt": 1,
        "artifact_name": "architecture-governance-evidence",
        "...": "workflow name and authoritative source URI"
      },
      "subjects": [
        {
          "id": "architecture_governance_report",
          "algorithm": "sha256",
          "digest": "<64 lowercase hexadecimal characters>",
          "...": "evidence reference and byte size"
        }
      ],
      "custody": [
        {"action": "download", "...": "actor, time, source, outputs"},
        {"action": "extract_and_hash", "...": "actor, time, source, outputs"}
      ],
      "errors": []
    }
  }
}
```

The complete contract and example are
`schemas/evidence-trust-record.schema.json` and
`docs/examples/evidence-trust-record.example.json`. The intake collector may
record claims and hashes, but `not_evaluated` requires `unverified`, a null
verifier, a null verification timestamp, and no verification checks.

For new automated intake, `trust.capture` also conforms to the versioned
Evidence Collector Contract described in
`docs/operations/evidence/evidence-collector-contract.md`. Historical capture
records retain their legacy string collector identity and remain valid.

## Chain Of Custody

For each newly intaken artifact, additive capture retains or references:

- authoritative source URI
- collector identity
- collection timestamp
- raw archive digest
- extracted evidence digests
- the download and extract-and-hash steps

Phase 3 still needs normalization transformation identifiers, a normalized
snapshot digest, and linkage to a previous verification record when
re-verifying.

Large raw artifacts may remain in the platform evidence store. The central
snapshot needs stable references and digests, not a duplicate raw archive.

## Freshness And Replay

Freshness must be contextual. A release approval, vulnerability scan, SBOM,
architecture review, and runtime observation may require different validity
rules. The provisional, versioned policy set is defined in
`model/evidence/evidence-freshness-policies.yaml`:

| Evidence type | Provisional validity rule | Current evaluation |
|---|---|---|
| Governance result | maximum age 24 hours | evaluated during DevSecOps and architecture intake |
| Vulnerability scan | maximum age 24 hours | evaluated by the typed collector pilot |
| Runtime evidence | maximum age 30 minutes | configured; waits for typed evidence timestamp |
| Architecture review | maximum age 180 days | configured; waits for typed approval timestamp |
| SBOM | must match the evaluated subject digest | configured; waits for subject binding |
| Release approval | must match the exact release candidate | configured; waits for candidate binding |

The vulnerability-scan pilot's command, input format, Trust output, Freshness
behavior, and current integration boundary are documented in
`docs/operations/evidence/vulnerability-scan-collector-usage.md`.

Version `0.1.0` is deliberately `provisional` and `report_only`. Missing
metadata produces `not_evaluated`; an expired or future-dated governance
result produces a failed Trust check without changing its governance outcome,
latest-result selection, or delivery behavior. Later changes require a new
GCR and policy version. Existing assessments are preserved and are not
reclassified retrospectively.

The report-only replay key binds:

```text
repository + commit + workflow + run + run_attempt + artifact + subject_digest
```

Reusing the same digest is not automatically invalid. Reuse within the same
repository, commit, and artifact context is compatible. Reuse across a
different repository, commit, or artifact context is recorded as a report-only
finding. Re-intake of the identical key is idempotent. A conflicting payload
for an existing snapshot path is quarantined without overwriting history.

The derived Replay Triage projection in
`generated/reports/replay-triage.json` applies current rules to the stored
chronology without rewriting it. It keeps the recorded result separate from
the current interpretation and classifies compatible reuse, deterministic
report reuse, legacy supersession, and incompatible cross-context reuse. The
operating model is documented in
`docs/operations/evidence/replay-triage.md`.

## Migration Plan

### Phase 1: Model And Gap Assessment

- complete
- validate this structured model
- keep all trust behavior report-only
- do not rewrite historical snapshots

### Phase 2: Additive Capture

- complete
- add optional trust metadata
- add architecture content and archive digests
- add run attempt and custody fields to both intake paths
- preserve existing schema compatibility

### Phase 3: Verification Projection

- current
- centralize trust-level derivation
- evaluate governance-result freshness with provisional policy v0.1
- evaluate replay identity and incompatible digest reuse centrally
- expose trust separately from governance result in indexes and viewer
- expose report-only replay triage without retrospective reclassification
- keep findings report-only

### Phase 4: Attestation Pilot

- complete as a report-only technical pilot
- verify an Ed25519 signature against a public demo trust root
- bind repository, commit, run, run attempt, artifact, subject identifier, and
  SHA-256 digest in one canonical statement
- expose `candidate_level: attested` without promoting operational Trust
- retain production issuer approval, key lifecycle, producer emission, and
  complete provenance prerequisites as explicit gaps

### Phase 5: Enforcement Decision

- evaluate migration and release impact
- define exception and downgrade behavior
- require explicit approval before any trust signal becomes blocking

## Open Decisions

| Decision | Required review |
|---|---|
| Production issuer and trust-root registry | Security, Platform, Governance |
| Approve or revise provisional freshness policy v0.1 | Control owners, Security, Operations |
| Initial attestation format and predicate | Security, Platform, Architecture |
| Trust requirements for protected mainline or release | Governance, Security, Release Manager |

Approval of the provisional Freshness policy blocks completion of Phase 3,
not its current report-only use. The other decisions block operational
attestation and enforcement. The local technical pilot is documented in
`docs/operations/evidence/evidence-attestation-pilot.md`.

## Latest-State And Viewer Impact

Version 1 does not change which result becomes `latest_result`. Mainline push
selection remains unchanged, and branch and manual history remain separate.
Indexes and the viewer now show evidence trust next to, but never instead of,
the governance result. Historical snapshots without a Trust record project as
`unverified` with assessment status `not_available`.

## Release Decision

No baseline release is required for the report-only Phase 3 projection because:

- the change affects central intake snapshots, internal indexes, and the viewer
- no downstream producer field becomes mandatory
- existing snapshots remain valid
- OPA and workflow enforcement are unchanged
- the model is report-only

Any schema change consumed by downstream repositories or any trust-based gate
requires a separate release and migration decision.
