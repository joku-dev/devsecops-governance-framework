# DevSecOps Governance Framework

Aktueller Funktionsumfang: [detaillierter Katalog mit 21 Bereichen](docs/operations/guides/repository-function-catalog.md)
und [vollständige technische Funktionsliste](docs/operations/guides/repository-technical-function-inventory.md).
Der [GitHub-Lifecycle-Pilot](docs/operations/status/governance-lifecycle-current-state.md)
ist seit der persönlichen LD-07-Abnahme und den geprüften Merges #92/#93 am
13. September 2026 aktiv, manuell und report-only.

The [v0.2.0 adoption/operations release](docs/releases/v0.2.0-public-adoption.md)
packages the controlled pilot state and publication downloads; its release
statement explains publication status and separate baseline pins.

The current accepted governance results from 16 September and the measured
ha-CPsWMS evidence from 17 September 2026 are recorded in the
[current platform state](docs/operations/status/current-governance-platform-state.md).

For current pilot and central operations, start with the
[operations handbook](docs/operations/guides/governance-repository-operations-handbook.md).
It links the [daily report](docs/operations/status/daily-governance-operations.md),
[access maintenance](docs/operations/security/github-access-and-token-maintenance.md),
and [backup and recovery](docs/operations/processes/governance-repository-backup-and-recovery.md).
Dated reference runs and released documentation remain historical evidence.

This public repository provides reusable DevSecOps and architecture governance baselines that application repositories can consume from CI/CD without copying governance logic into every project.

It combines governance-as-code, policy-as-code, machine-readable evidence, released baselines, runtime architecture governance, onboarding guidance, and CI/CD adapter patterns for GitHub Actions, Bamboo/Bitbucket, Jenkins, and GitLab CI.

The repository models a governance stack where a `Policy` defines mandatory intent, a `Directive` defines binding operational execution, and structured baseline artifacts define detailed controls, platform expectations, evidence contracts, and executable checks.

## Start Here

| Need | Entry point |
|---|---|
| Review the public adoption state | `docs/onboarding/external-review-brief.md` |
| Run an external evaluation | `docs/onboarding/external-evaluator-guide.md` |
| Run a controlled adoption pilot | `docs/onboarding/pilot-runbook.md` |
| Try the framework in an application repo | `docs/onboarding/public-repo-quickstart.md` |
| Copy ready-to-use templates | `adoption-package/README.md` |
| Inspect the validated neutral consumer | `docs/onboarding/validated-demo-consumer.md` |
| Review the current public release | `docs/releases/v0.2.0-public-adoption.md` |
| Inspect current repository capabilities | `docs/operations/guides/repository-function-catalog.md` |
| Open the governance viewer | `https://joku-dev.github.io/devsecops-governance-framework/generated/viewer/app/index.html` |
| Open the published documentation | `https://joku-dev.github.io/devsecops-governance-framework/` |

## Use In Three Steps

1. Copy the workflows from `adoption-package/workflows/` into an application repository.
2. Keep the first runs in `report-only` and review the generated artifacts.
3. Replace placeholder evidence with real scanner, SBOM, repository-control and architecture evidence. New blocking additionally requires the [readiness assessment](docs/operations/status/blocking-readiness.md), accountable approval and a separate consumer change.

## Purpose

The repository separates these concerns:

| Area | Purpose |
|---|---|
| `docs/` | Human-readable governance documentation, onboarding guides, adapter guidance, and operational explanations. |
| `docs/governance/source-documents` | Public source placeholders for lineage only; original source documents are withheld from the public repository. |
| `model/documents` | Structured catalog of policy, directive, and standard source documents. |
| `model/controls` | Structured DevSecOps control baseline requirements. |
| `model/platform` | Platform Reference Architecture levels and platform capabilities. |
| `model/traceability` | Mapping between controls, platform capabilities, evidence, and policy candidates. |
| `architecture` | Architecture runtime governance levels, markers, guardrails, review gates, and remediation actions. |
| `pipeline-baseline` | Tool-agnostic CI/CD control baseline and platform-specific adapter templates. |
| `policies/opa` | Executable policy-as-code rules for automated checks. |
| `model/evidence` | Evidence type definitions expected from pipelines and platforms. |
| `model/waivers` | Waiver model and approval authority structure. |
| `schemas` | JSON Schemas for validating structured governance data. |
| `status` | Normalized downstream governance and architecture result snapshots. |
| `generated` | Derived reports, traceability, graph and viewer; generated document exports where configured. |
| `releases` | Versioned baseline packages for controlled publication. |

## Target Model

The long-term target is that structured sources become the controlled master data for software delivery governance. Word and PDF remain important output formats for reviews and audits, but original source documents are not published in this public repository.

```mermaid
flowchart TD
    A["Control Library YAML"] --> B["Generated Word/PDF"]
    A --> C["Traceability Matrix"]
    A --> D["Policy-as-Code Rules"]
    D --> E["CI/CD and Platform Checks"]
    E --> F["Machine Evidence"]
```

## Initial Scope

The initial scope is based on:

- DevSecOps Control Baseline Standard aligned with Platform Levels
- DevSecOps Platform Reference Architecture Standard aligned with Control Baseline

The initial implementation established:

- Level 1 controls as complete structured data
- Platform Reference Architecture levels 1 to 3
- Traceability from control requirement to platform capability and expected evidence
- Initial automated checks for branch protection, SBOM, vulnerability evidence, artifact integrity, dependency source control, IaC, and waiver validity

## Runtime Governance Addendum

The repository now includes a first runtime governance addendum for the SDD Architecture Governance Framework:

- `docs/governance/architecture/runtime-governance-addendum.md`
- `architecture/quality-markers.yaml`
- `architecture/guardrails.yaml`
- `architecture/review-gates.yaml`
- `architecture/arch-l1.yaml`
- `architecture/arch-l2.yaml`
- `architecture/arch-l3.yaml`
- `architecture/arch-gov.yaml`
- `policies/opa/architecture_readiness.rego`
- `policies/opa/architecture_integration_readiness.rego`
- `policies/opa/architecture_operation_readiness.rego`
- `policies/opa/architecture_release_readiness.rego`

The addendum keeps the original framework document as the normative reference and adds machine-readable marker, guardrail, gate and policy artifacts for executable governance.

## Recommended Workflow

1. Maintain structured control and platform data in YAML.
2. Validate YAML against JSON Schemas.
3. Generate traceability views and documents from YAML.
4. Implement policy-as-code only for controls that can be objectively checked.
5. Store generated evidence from pipelines and platform checks.
6. Use waivers only as controlled, time-limited exceptions.

## Repository Layout

- `docs/` explains the governance model for people.
- `model/` contains the machine-readable governance source of truth.
- `generated/` contains rendered documents, reports, and viewer output.
- `releases/` is reserved for versioned baseline packages.
- `.github/workflows/` contains repository automation and reusable CI integration.

## Current Operational State

- `L1` is now available as a released and revision-protected baseline package via `l1-baseline-v1.1.3`.
- The current `L1 v1.1.3` package adds run-context-aware evaluation for release, pull-request, branch-validation, and diagnostic runs.
- `architecture-baseline-l1-v0.1.0` is available as the released architecture runtime governance baseline.
- GitHub Pages publishes the documentation and the read-only Governance Workspace with repository, finding, evidence, governance and operations views.
- Central intake stores append-only DevSecOps, architecture, typed evidence, measured L1 and control-assurance snapshots under `status/`; reviewed operational PRs update the official indexes.
- Evidence Trust records integrity, provenance, freshness, replay, custody and attestation without turning evidence quality into a compliance or release decision.
- The ha-CPsWMS pilot produces real tests, SAST, five container builds, CycloneDX SBOMs, Trivy scans and HTTP/Neo4j integration evidence. Its latest measured L1 assessment covers all 16 controls and leaves missing or partial evidence explicit.
- The manual closed-loop lifecycle pilot can record observations, decisions, actions, receipts, closure and revocation for its narrowly accepted scope. It remains report-only and subject to personal action consent.
- `governance-framework-demo-consumer` is the neutral public reference consumer for first adoption validation.
- Platform-neutral evidence generation, validation and bundle intake support adapter paths for GitHub Actions, Bamboo with Bitbucket Data Center, Bitbucket Pipelines, Jenkins and GitLab CI. The non-GitHub paths are reference implementations that require environment-specific integration and validation.

Current accepted ha-CPsWMS governance runs are DevSecOps
[`35131186298`](https://github.com/joku-dev/ha-CPsWMS/actions/runs/35131186298)
and architecture
[`35131185047`](https://github.com/joku-dev/ha-CPsWMS/actions/runs/35131185047).
The separate measured-evidence run
[`35241262722`](https://github.com/joku-dev/ha-CPsWMS/actions/runs/35241262722)
contains 58 passing tests, typed vulnerability and SBOM evidence, and the
per-control assurance projection. A governance PASS remains distinct from open
scanner findings, replay deviations and production approval.

## AI And Agent Navigation

- Agent instructions: `AGENTS.md`
- AI navigation index: `docs/ai-index.md`
- AI working rules: `docs/operations/ai-working-rules.md`

## License And Permissions

- Proprietary license notice: `LICENSE`
- Repository license and permissions: `LICENSE_AND_PERMISSIONS.md`

## Governance Change Lifecycle

- Governance change lifecycle: `docs/governance/governance-change-lifecycle.md`
- Source document register: `model/documents/source-document-register.yaml`
- Source document intake process: `docs/operations/processes/source-document-intake-process.md`
- Source document intake status: `generated/reports/source-document-intake-status.md`
- Source document intake review briefs: `generated/reports/source-document-intake-review-briefs.md`
- Source document requirement delta: `generated/reports/source-document-requirement-delta.md`
- Change request template: `docs/governance/change-requests/TEMPLATE.md`

## Local Commands

Prepare the pinned local validation toolchain and run all required checks:

```bash
./scripts/bootstrap_validation_env.sh
./scripts/validate_all.sh
```

See `docs/operations/guides/local-validation-toolchain.md` for supported
platforms, custom installation paths, pinned dependencies, and troubleshooting.

For the focused commands below, activate the prepared environment first:

```bash
source .venv-validation/bin/activate
```

Validate repository consistency:

```bash
python scripts/validate_governance_repo.py
```

Generate the source-document intake status report:

```bash
python scripts/generate_source_document_intake_status.py
```

Generate source-document intake review briefs:

```bash
python scripts/generate_source_document_intake_review_briefs.py
```

Generate source-document requirement deltas for replacement candidates:

```bash
python scripts/generate_source_document_requirement_delta.py
```

Review the governance document hierarchy:

```bash
sed -n '1,200p' docs/governance/governance-document-hierarchy.md
```

Run the lightweight regression checks:

```bash
python -m unittest discover -s tests
```

Read the practical usage guide:

```bash
sed -n '1,240p' docs/operations/guides/how-to-use-this-repo.md
```

Read the GitHub reference path guardrails:

```bash
sed -n '1,240p' docs/operations/adapters/github-reference-path.md
```

Read the beginner step-by-step operations guide:

```bash
sed -n '1,320p' docs/operations/guides/beginner-step-by-step-operations-guide.md
```

Read how other repositories integrate this governance repository:

```bash
sed -n '1,320p' docs/onboarding/how-other-repos-use-this-governance-repo.md
```

Read the step-by-step central governance baseline integration guide:

```bash
sed -n '1,320p' docs/onboarding/how-other-repositories-use-the-central-governance-baseline.md
```

Read the application repository onboarding guide:

```bash
sed -n '1,260p' docs/onboarding/application-repo-onboarding.md
```

Use the copyable public adoption package:

```bash
sed -n '1,220p' adoption-package/README.md
```

Inspect the validated neutral demo consumer:

```bash
sed -n '1,220p' docs/onboarding/validated-demo-consumer.md
```

Read the explanation of policy, directive, baseline, verification, and governance as code:

```bash
sed -n '1,360p' docs/governance/policy-directive-baseline-verification-and-governance-as-code-explained.md
```

Read the explanation of the relationship between the control baseline and the platform architecture:

```bash
sed -n '1,320p' docs/platform/control-baseline-and-platform-architecture-relationship-explained.md
```

Use the generic GitHub Actions onboarding template:

```bash
sed -n '1,180p' examples/github-actions/workflows/application-devsecops-baseline-template.yml
```

Use the governance-input-aware onboarding template:

```bash
sed -n '1,260p' examples/github-actions/workflows/application-devsecops-baseline-with-governance-input-template.yml
```

Read the operational governance enforcement options:

```bash
sed -n '1,240p' docs/operations/processes/operational-governance-enforcement-options.md
```

Generate an extended machine-readable governance compliance result:

```bash
python3 scripts/generate_governance_compliance_result.py \
  --target-repo . \
  --input-file policies/example-input.release-candidate.json \
  --output-file governance-compliance-result.json
```

GitHub Actions runs the same core checks automatically on pushes and pull requests via `.github/workflows/governance-ci.yml`.

Generate the first traceability CSV:

```bash
python scripts/generate_traceability_csv.py
```

Generate the governance document authority matrix:

```bash
python scripts/generate_document_control_matrix.py
```

Generate the open gap report:

```bash
python scripts/generate_open_gap_report.py
```

Render the Policy and Directive into review-ready files:

```bash
python scripts/render_governance_documents.py
```

Generate the static governance status viewer:

```bash
python scripts/generate_status_viewer.py
```

Generate a control-by-control evaluation report for a specific governance run input:

```bash
python scripts/generate_control_evaluation_report.py \
  --input-file demo/inputs/release-candidate-green.json \
  --output-file generated/control-evaluation-report.json \
  --markdown-file generated/control-evaluation-report.md
```

Build the documentation site locally:

```bash
python3 -m venv .venv-docs
. .venv-docs/bin/activate
pip install -r requirements-docs.txt
mkdocs build --strict
mkdocs serve
```

Read the full step-by-step MkDocs and GitHub Pages guide:

```bash
sed -n '1,360p' docs/operations/guides/mkdocs-and-github-pages-step-by-step.md
```

Use the first versioned L1 baseline release package:

```bash
sed -n '1,240p' releases/l1/v1.0.0/baseline-package.md
sed -n '1,200p' docs/releases/l1-baseline-v1.0.0.md
```

Inspect the earlier L1 release package that introduced governance run input support:

```bash
sed -n '1,240p' releases/l1/v1.1.0/baseline-package.md
sed -n '1,220p' docs/releases/l1-baseline-v1.1.0.md
```

Inspect the current L1 release package with run-context-aware evaluation:

```bash
sed -n '1,240p' releases/l1/v1.1.3/baseline-package.md
sed -n '1,220p' docs/releases/l1-baseline-v1.1.3.md
```

Generate the central repository results index:

```bash
python3 scripts/generate_repository_results_index.py
sed -n '1,220p' status/repository-results-index.json
```

Run the local demonstration environment:

```bash
python scripts/run_demo.py
```

Generate the architecture runtime traceability CSV:

```bash
python3 scripts/generate_architecture_traceability_csv.py
```

Validate the runtime governance addendum:

```bash
python3 scripts/validate_runtime_governance.py
```

Generate a demo architecture release-readiness input for a local application repository:

```bash
python3 scripts/collect_architecture_release_input.py \
  --repo /workspace/governance-framework-demo-consumer \
  --output generated/demo/demo-consumer-architecture-release-input.json \
  --release-id demo-consumer \
  --baseline example-solution-baseline
```

Generate a demo architecture governance report:

```bash
python3 scripts/generate_architecture_governance_report.py \
  --input generated/demo/demo-consumer-architecture-release-input.json \
  --output-json generated/demo/demo-consumer-architecture-governance-report.json \
  --output-md generated/demo/demo-consumer-architecture-governance-report.md
```

Generate a demo DevSecOps governance report:

```bash
python3 scripts/collect_devsecops_release_input.py \
  --repo /workspace/governance-framework-demo-consumer \
  --output generated/demo/demo-consumer-devsecops-release-input.json \
  --release-id demo-consumer

python3 scripts/generate_devsecops_governance_report.py \
  --input generated/demo/demo-consumer-devsecops-release-input.json \
  --output-json generated/demo/demo-consumer-devsecops-governance-report.json \
  --output-md generated/demo/demo-consumer-devsecops-governance-report.md
```

By default, this local report is report-only. `--fail-on-findings` is the technical
blocking switch; use it in a consumer only after readiness review and accountable
approval. The released DevSecOps wrapper has a separate default of `block-on-error`.

Generate the combined end-to-end demo report:

```bash
python3 scripts/generate_end_to_end_governance_report.py \
  --architecture-json generated/demo/demo-consumer-architecture-governance-report.json \
  --devsecops-json generated/demo/demo-consumer-devsecops-governance-report.json \
  --output-json generated/demo/demo-consumer-end-to-end-governance-report.json \
  --output-md generated/demo/demo-consumer-end-to-end-governance-report.md
```

Intake a downstream Architecture Runtime Governance GitHub Actions run and refresh the architecture status index:

```bash
python3 scripts/intake_architecture_github_actions_run.py \
  --repository-id joku-dev/governance-framework-demo-consumer \
  --run-id 34606820390 \
  --architecture-baseline-ref architecture-baseline-l1-v0.1.0

python3 scripts/generate_architecture_results_index.py
python3 scripts/generate_status_viewer.py
```

The detailed live demo runbook is:

```text
docs/demos/demo-end-to-end-governance.md
```

The validated neutral demo consumer is documented here:

```text
docs/onboarding/validated-demo-consumer.md
```

The reusable GitHub Actions template for application repositories is:

```text
pipeline-baseline/templates/github-actions/architecture-governance.yml
```

For the minimal copy-paste app-repo workflow and onboarding guide, see:

```text
pipeline-baseline/templates/github-actions/app-repo-architecture-governance.yml
pipeline-baseline/templates/github-actions/ADOPTION.md
```

Optional app-repo evidence templates are available in:

```text
pipeline-baseline/templates/app-architecture-evidence/
```

The released Architecture Runtime Governance baseline is consumed like this:

```yaml
uses: joku-dev/devsecops-governance-framework/.github/workflows/architecture-baseline-l1-v0.1.0.yml@architecture-baseline-l1-v0.1.0
with:
  solution_baseline: example-solution-baseline
  fail_on_findings: false
```

`architecture-baseline-l1-v0.1.0` is the architecture governance baseline. `example-solution-baseline` is the solution/product baseline used by the application evidence.

## Important Principle

Not every requirement should become executable policy. Some requirements are governance obligations, some are evidence obligations, and some are enforceable technical gates. The repository keeps these concerns connected but distinct.
