#!/usr/bin/env python3
"""Aggregate Architecture Runtime Governance results into a central index."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import json

from lib.evidence_trust import project_trust


ROOT = Path(__file__).resolve().parents[1]
STATUS_RESULTS = ROOT / "status" / "architecture-results"
INDEX_PATH = ROOT / "status" / "architecture-results-index.json"


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    repositories = []
    result_count = 0
    passing_results = 0
    findings_results = 0
    mainline_results = 0
    branch_results = 0
    manual_results = 0
    trust_level_counts = {}

    if not STATUS_RESULTS.exists():
        STATUS_RESULTS.mkdir(parents=True)

    for repo_dir in sorted(path for path in STATUS_RESULTS.iterdir() if path.is_dir()):
        results = sorted(repo_dir.glob("*.json"))
        if not results:
            continue
        parsed = [(load_json(path), path) for path in results]
        parsed.sort(key=lambda pair: (pair[0].get("generated_at", ""), str(pair[1])))
        latest = parsed[-1][0]
        latest_main = None
        for item, _ in reversed(parsed):
            if item.get("repository", {}).get("branch") == "main" and item.get("pipeline", {}).get("event") == "push":
                latest_main = item
                break
        representative = latest_main or latest
        result_count += len(parsed)
        for item, _ in parsed:
            level = project_trust(item)["effective_level"]
            trust_level_counts[level] = trust_level_counts.get(level, 0) + 1
            if item.get("overall_status") == "pass":
                passing_results += 1
            else:
                findings_results += 1
            if item.get("pipeline", {}).get("event") == "workflow_dispatch":
                manual_results += 1
            elif item.get("repository", {}).get("branch") == "main":
                mainline_results += 1
            else:
                branch_results += 1

        history = []
        for item, path in parsed:
            history.append(
                {
                    "generated_at": item.get("generated_at", ""),
                    "status": item.get("overall_status", "unknown"),
                    "pipeline_run_id": item.get("pipeline", {}).get("pipeline_run_id", "unknown"),
                    "pipeline_event": item.get("pipeline", {}).get("event", "unknown"),
                    "pipeline_url": item.get("pipeline", {}).get("pipeline_url", ""),
                    "branch": item.get("repository", {}).get("branch", "unknown"),
                    "commit_id": item.get("repository", {}).get("commit_id", "unknown"),
                    "architecture_baseline_ref": item.get("architecture_baseline_ref", "unknown"),
                    "architecture_summary": item.get("architecture_summary", {}),
                    "trust": project_trust(item),
                    "source_file": str(path.relative_to(ROOT)),
                }
            )

        repositories.append(
            {
                "repository_id": latest["repository_id"],
                "architecture_baseline_ref": representative.get("architecture_baseline_ref", "unknown"),
                "results_path": f"status/architecture-results/{repo_dir.name}/",
                "latest_result": {
                    "status": representative.get("overall_status", "unknown"),
                    "pipeline_run_id": representative.get("pipeline", {}).get("pipeline_run_id", "unknown"),
                    "commit_id": representative.get("repository", {}).get("commit_id", "unknown"),
                    "generated_at": representative.get("generated_at", ""),
                    "architecture_baseline_ref": representative.get("architecture_baseline_ref", "unknown"),
                    "pipeline_url": representative.get("pipeline", {}).get("pipeline_url", ""),
                    "branch": representative.get("repository", {}).get("branch", "unknown"),
                    "pipeline_event": representative.get("pipeline", {}).get("event", "unknown"),
                    "source_file": next(
                        str(path.relative_to(ROOT))
                        for item, path in parsed
                        if item == representative
                    ),
                    "architecture_summary": representative.get("architecture_summary", {}),
                    "trust": project_trust(representative),
                },
                "history": history,
            }
        )

    payload = {
        "schema_version": "1.0.0",
        "generated_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "summary": {
            "repository_count": len(repositories),
            "result_count": result_count,
            "passing_results": passing_results,
            "findings_results": findings_results,
            "mainline_results": mainline_results,
            "branch_results": branch_results,
            "manual_results": manual_results,
            "trust_level_counts": trust_level_counts,
        },
        "repositories": repositories,
    }
    INDEX_PATH.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {INDEX_PATH.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
