# Official Entrypoints

[Governance Workspace öffnen](https://joku-dev.github.io/devsecops-governance-framework/generated/viewer/app/index.html) · [Bedienung und Datenherkunft](operations/guides/governance-viewer-app.md)

Aktueller Funktionsumfang: [detaillierter Katalog mit 21 Bereichen](operations/guides/repository-function-catalog.md)
und [vollständige technische Funktionsliste](operations/guides/repository-technical-function-inventory.md).
Der [GitHub-Lifecycle-Pilot](operations/status/governance-lifecycle-current-state.md)
ist seit der persönlichen LD-07-Abnahme und den geprüften Merges #92/#93 am
13. September 2026 aktiv, manuell und report-only.

Current accepted governance results from 16 September and measured ha-CPsWMS
evidence from 17 September 2026 are recorded in the
[current platform state](operations/status/current-governance-platform-state.md).

For current pilot and central operations, start with the
[operations handbook](operations/guides/governance-repository-operations-handbook.md).
It links the [daily report](operations/status/daily-governance-operations.md),
[access maintenance](operations/security/github-access-and-token-maintenance.md),
and [backup and recovery](operations/processes/governance-repository-backup-and-recovery.md).
Dated reference runs and released documentation remain historical evidence.

## Purpose

This page provides a single navigation point for the most important official documents in this repository.

It is intended for:

- new contributors
- governance owners
- downstream repository teams
- reviewers and auditors

## Start Here

- Repository overview: `README.md`
- Documentation landing page: `docs/index.md`
- External review brief: `docs/onboarding/external-review-brief.md`
- External evaluator guide: `docs/onboarding/external-evaluator-guide.md`
- Pilot runbook: `docs/onboarding/pilot-runbook.md`
- Public quickstart: `docs/onboarding/public-repo-quickstart.md`
- Validated neutral demo consumer: `docs/onboarding/validated-demo-consumer.md`
- Adoption/operations release: `docs/releases/v0.2.0-public-adoption.md`
- Reading compass for new team members: `docs/lesekompass.md`
- Role-based documentation paths: `docs/paths/index.md`
- AI navigation index: `docs/ai-index.md`
- Agent instructions: `AGENTS.md`

## Role-Based Paths

- Beginner path: `docs/paths/beginner-path.md`
- Operator path: `docs/paths/operator-path.md`
- Auditor path: `docs/paths/auditor-path.md`
- Maintainer path: `docs/paths/maintainer-path.md`

## Governance Documents

- Policy: `docs/governance/devsecops-policy.md`
- Directive: `docs/governance/devsecops-directive.md`
- Governance change lifecycle: `docs/governance/governance-change-lifecycle.md`
- Governance roles and agent profiles: `docs/governance/governance-roles-and-agent-profiles.md`
- Policy, Directive, Baseline, Verification, and Governance as Code: `docs/governance/policy-directive-baseline-verification-and-governance-as-code-explained.md`
- Source of Truth: `docs/governance/source-of-truth.md`
- Operating Model: `docs/governance/operating-model.md`
- Governance-as-Code System Architecture: `docs/governance/architecture/governance-as-code-system-architecture.md`
- ADO and DevSecOps-as-Code integrated governance model: `docs/governance/architecture/ado-devsecops-integrated-governance-model.md`
- Software Industrialisation Problem and Capability Map: `docs/governance/architecture/software-industrialisation-problem-capability-map.md`
- Governance Repository Architecture Comparison: `docs/governance/architecture/governance-repository-architecture-comparison.md`
- Runtime Governance Addendum: `docs/governance/architecture/runtime-governance-addendum.md`
- Runtime Governance Transformation: `docs/governance/architecture/runtime-governance-transformation.md`
- DevSecOps Governance Organisational Role Model: `docs/governance/devsecops-governance-organisational-role-model.md`
- Governance Document Hierarchy: `docs/governance/governance-document-hierarchy.md`
- Source document register: `model/documents/source-document-register.yaml`
- Governance change request template: `docs/governance/change-requests/TEMPLATE.md`

## Onboarding Documents

- External review brief: `docs/onboarding/external-review-brief.md`
- External evaluator guide: `docs/onboarding/external-evaluator-guide.md`
- Pilot runbook: `docs/onboarding/pilot-runbook.md`
- Public repository quickstart: `docs/onboarding/public-repo-quickstart.md`
- Validated demo consumer: `docs/onboarding/validated-demo-consumer.md`
- Application repository onboarding: `docs/onboarding/application-repo-onboarding.md`
- How other repositories use this governance repository: `docs/onboarding/how-other-repos-use-this-governance-repo.md`
- How other repositories use the central governance baseline: `docs/onboarding/how-other-repositories-use-the-central-governance-baseline.md`

## Operations Documents

- How to use this repository: `docs/operations/guides/how-to-use-this-repo.md`
- AI working rules: `docs/operations/ai-working-rules.md`
- Beginner step-by-step operations guide: `docs/operations/guides/beginner-step-by-step-operations-guide.md`
- Local validation toolchain: `docs/operations/guides/local-validation-toolchain.md`
- Evidence- und Governance-Hardening: `docs/operations/guides/evidence-and-governance-hardening-guide.md`
- How to add a new artifact: `docs/operations/guides/how-to-add-a-new-artifact.md`
- Governance evidence contract: `docs/operations/evidence/governance-evidence-contract.md`
- Evidence Trust Model: `docs/operations/evidence/evidence-trust-model.md`
- Evidence Collector Contract: `docs/operations/evidence/evidence-collector-contract.md`
- Vulnerability Scan Collector Usage: `docs/operations/evidence/vulnerability-scan-collector-usage.md`
- Demo Consumer Typed Evidence Trust: `docs/demos/demo-consumer-typed-evidence-trust.md`
- Präsentationsanleitung Typed Evidence Trust: `docs/demos/presentation-guide-typed-evidence-trust-de.md`
- How to update baseline input documents: `docs/operations/guides/how-to-update-baseline-input-documents.md`
- Governance evidence schema versioning: `docs/operations/evidence/governance-evidence-schema-versioning.md`
- New artifact intake process: `docs/operations/processes/new-artifact-intake-process.md`
- Waiver management standard: `docs/operations/processes/waiver-management-standard.md`
- Source document intake process: `docs/operations/processes/source-document-intake-process.md`
- Source document intake review operating model: `docs/operations/processes/source-document-intake-review-operating-model.md`
- Current governance platform state: `docs/operations/status/current-governance-platform-state.md`
- Governance Intelligence Graph Viewer: `docs/operations/status/governance-intelligence-graph-viewer.md`
- How to read control evaluation status: `docs/operations/evidence/how-to-read-control-evaluation-status.md`
- Governance result intake and viewer usage: `docs/operations/evidence/governance-result-intake-and-viewer-usage.md`
- Governance Workspace guide: `docs/operations/guides/governance-viewer-app.md`
- Measured ha-CPsWMS L1 evidence and control assurance: `docs/operations/evidence/l1-measured-evidence-ha-cpswms.md`
- Intake operation telemetry: `docs/operations/evidence/intake-operation-telemetry.md`
- Bitbucket and Bamboo governance adapter: `docs/operations/adapters/bitbucket-bamboo-governance-adapter.md`
- Agent system usage: `docs/operations/agents/agent-system-usage.md`
- Agent usage tracking: `docs/operations/agents/agent-usage-tracking.md`
- Latest agent usage snapshot: `docs/operations/agents/agent-usage-snapshot-latest.md`
- MkDocs and GitHub Pages step by step: `docs/operations/guides/mkdocs-and-github-pages-step-by-step.md`
- Operational governance enforcement options: `docs/operations/processes/operational-governance-enforcement-options.md`
- Documentation structure model: `docs/operations/planning/document-structure-model.md`
- Documentation structure audit: `docs/operations/planning/document-structure-audit.md`
- Closed-loop governance durable pilot intake: `docs/operations/evidence/governance-lifecycle-durable-pilot-intake.md`
- Closed-loop governance personal channel probe: `docs/operations/evidence/governance-lifecycle-personal-channel.md`
- Closed-loop governance action consent: `docs/operations/evidence/governance-lifecycle-action-consent.md`
- Closed-loop governance GitHub pilot operation: `docs/operations/evidence/governance-lifecycle-live-operation.md`
- Closed-loop governance live evidence preflight: `docs/operations/evidence/governance-lifecycle-live-evidence-preflight.md`
- Closed-loop governance confirmed pilot roles and disabled profile: `docs/operations/evidence/governance-lifecycle-live-preparation.md`
- Closed-loop governance live decision brief: `docs/operations/evidence/governance-lifecycle-live-decision-brief.md`
- Closed-loop governance input candidates (CLG-06.3, diagnostic): `docs/operations/evidence/governance-lifecycle-input-candidates.md`
- Closed-loop governance scenario viewer (CLG-06.2, synthetic): `docs/operations/evidence/governance-lifecycle-viewer.md`
- Closed-loop governance scenario metrics (CLG-06.1, synthetic): `docs/operations/evidence/governance-lifecycle-overview.md`
- Closed-loop governance exceptions (CLG-05, synthetic): `docs/operations/evidence/governance-lifecycle-exceptions.md`
- Closed-loop governance closure pilot (CLG-04, synthetic): `docs/demos/demo-governance-lifecycle-pilot.md`
- Closed-loop governance decisions (CLG-03, synthetic): `docs/operations/evidence/governance-lifecycle-decisions.md`
- Closed-loop governance kernel (CLG-02, synthetic): `docs/operations/evidence/governance-lifecycle-kernel.md`
- Closed-loop governance contracts (CLG-01, offline): `docs/operations/evidence/governance-lifecycle-contract.md`
- Closed-loop governance implementation progress and remaining work: `docs/operations/planning/closed-loop-governance-implementation-plan.md`

## Platform Explanation

- Control baseline and platform architecture relationship: `docs/platform/control-baseline-and-platform-architecture-relationship-explained.md`

## Control And Pipeline Guides

- Control baseline guide: `docs/controls/index.md`
- Generated control coverage report: `generated/reports/control-coverage-report.md`
- Governance change impact report: `generated/reports/governance-change-impact.md`
- Architecture source replacement assessment: `generated/reports/architecture-source-replacement-assessment.md`
- Source document intake status: `generated/reports/source-document-intake-status.md`
- Source document intake review briefs: `generated/reports/source-document-intake-review-briefs.md`
- Source document requirement delta: `generated/reports/source-document-requirement-delta.md`
- Pipeline baseline guide: `docs/pipeline-baseline/index.md`

## Release Documents

- Release overview: `docs/releases/index.md`
- Operational pilot repository release v0.2.0: `docs/releases/v0.2.0-public-adoption.md`
- Historical public adoption release v0.1.0: `docs/releases/v0.1.0-public-adoption.md`
- Release and migration model: `docs/releases/release-and-migration-model.md`
- Release publication checklist: `docs/releases/release-publication-checklist.md`
- L1 baseline v1.0.0: `docs/releases/l1-baseline-v1.0.0.md`
- L1 baseline v1.0.0 release statement: `docs/releases/l1-baseline-v1.0.0-release-statement.md`
- L1 baseline v1.1.0: `docs/releases/l1-baseline-v1.1.0.md`
- L1 baseline v1.1.0 release statement: `docs/releases/l1-baseline-v1.1.0-release-statement.md`
- L1 baseline v1.1.1: `docs/releases/l1-baseline-v1.1.1.md`
- L1 baseline v1.1.1 release statement: `docs/releases/l1-baseline-v1.1.1-release-statement.md`
- L1 baseline v1.1.2: `docs/releases/l1-baseline-v1.1.2.md`
- L1 baseline v1.1.2 release statement: `docs/releases/l1-baseline-v1.1.2-release-statement.md`
- L1 baseline v1.1.3: `docs/releases/l1-baseline-v1.1.3.md`
- L1 baseline v1.1.3 release statement: `docs/releases/l1-baseline-v1.1.3-release-statement.md`
- Current technical release package: `releases/l1/v1.1.3/baseline-package.md`

## Consumer Entrypoints

- Versioned reusable workflow: `.github/workflows/devsecops-baseline-l1-v1.0.0.yml`
- Prepared versioned reusable workflow: `.github/workflows/devsecops-baseline-l1-v1.1.0.yml`
- Prepared patch versioned reusable workflow: `.github/workflows/devsecops-baseline-l1-v1.1.1.yml`
- Prepared patch versioned reusable workflow: `.github/workflows/devsecops-baseline-l1-v1.1.2.yml`
- Prepared patch versioned reusable workflow: `.github/workflows/devsecops-baseline-l1-v1.1.3.yml`
- Consumer example workflow: `releases/l1/v1.0.0/examples/github-actions/devsecops-baseline-l1-v1.0.0.yml`
- Consumer example workflow with governance input: `releases/l1/v1.1.0/examples/github-actions/devsecops-baseline-l1-v1.1.0.yml`
- Consumer example workflow with governance input: `releases/l1/v1.1.1/examples/github-actions/devsecops-baseline-l1-v1.1.1.yml`
- Consumer example workflow with governance input: `releases/l1/v1.1.2/examples/github-actions/devsecops-baseline-l1-v1.1.2.yml`
- Consumer example workflow with run context: `releases/l1/v1.1.3/examples/github-actions/devsecops-baseline-l1-v1.1.3.yml`
- Governance run input schema: `schemas/governance-run-input.schema.json`
- Governance run input example: `docs/examples/governance-run-input.example.json`

## Governance Collaboration Entrypoints

- Pull request template: `.github/pull_request_template.md`
- CODEOWNERS: `.github/CODEOWNERS`

## Recommended Reading Order For New Users

1. `README.md`
2. `docs/lesekompass.md`
3. `docs/index.md`
4. `docs/paths/beginner-path.md`
5. `docs/operations/guides/beginner-step-by-step-operations-guide.md`
6. `docs/onboarding/application-repo-onboarding.md`
7. `docs/releases/l1-baseline-v1.1.3.md`
