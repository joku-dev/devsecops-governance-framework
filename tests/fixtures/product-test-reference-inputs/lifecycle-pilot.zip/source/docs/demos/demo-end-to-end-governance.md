# End-to-End Governance Demo Runbook

The separate [GRS-002 lifecycle pilot](../operations/status/governance-lifecycle-current-state.md)
now has personal operating acceptance. It does not change the ha-CPsWMS results
or demonstrate a real consumer remediation/closure.

This runbook contains accepted September mainline results and older, explicitly
dated reference examples. For
current operations, use the [operations handbook](../operations/guides/governance-repository-operations-handbook.md).
The existing ha-CPsWMS DevSecOps integration is a preserved legacy blocking risk,
with review due 12 December 2026; see [mode alignment](../operations/status/blocking-mode-alignment.md).
Explicitly select report-only for a diagnostic demonstration and inspect the
consumer trigger configuration before starting a live run. This runbook does not
authorize changing its registered mode or introducing new blocking.

## Purpose

This runbook describes the live demo for the governance-as-code repository with the
`joku-dev/ha-CPsWMS` application repository.

The demo shows the full loop:

1. Source governance documents are kept in the governance repository.
2. Machine-readable controls, architecture markers, policies and baselines are derived from those documents.
3. The application repository provides evidence and runs governance workflows.
4. The governance repository receives the downstream results through intake workflows.
5. The status viewer shows DevSecOps, architecture and source-lineage results together.

The target state for the demo is report-only. Findings should be visible and explainable, but the demo should not block delivery unless a workflow is explicitly configured to do so.

## Demo Message

Governance is no longer only a document or a review meeting. The governance repository keeps the source documents, translates them into versioned machine-readable baselines, evaluates application evidence, and publishes human-readable and machine-readable results.

For the demo, the important point is traceability:

- A source document explains the governance intent.
- A model file or OPA policy implements part of that intent.
- A released baseline freezes a reviewed version of that implementation.
- An application workflow runs against that baseline.
- The viewer shows the result and links back to the generated artifacts.

## Repositories

| Repository | Role | Demo branch |
|---|---|---|
| `joku-dev/devsecops-governance-framework` | Governance source, models, policies, baselines, intake and viewer | `main` |
| `joku-dev/ha-CPsWMS` | Application evidence and downstream GitHub Actions workflows | `main` |

Local paths used during development:

```text
/workspace/devsecops-governance-framework
/workspace/ha-CPsWMS
```

## Current Demo Baselines

| Domain | Baseline | Release package |
|---|---|---|
| DevSecOps | `l1-baseline-v1.1.3` | `releases/l1/v1.1.3/` |
| Architecture | `architecture-baseline-l1-v0.1.0` | `releases/architecture/l1/v0.1.0/` |
| Application solution | `ha-CPsWMS-demo-baseline` | Supplied by `ha-CPsWMS` architecture evidence |

Why this matters:

- DevSecOps and architecture are not evaluated from an unversioned working directory during the demo.
- The app repository can pin a released governance baseline.
- The viewer can show which baseline produced a result.

## Current Mainline Results

These values record the 16 September 2026 mainline runs, accepted through
intake PRs #109 and #110. Original artifact hashes and GitHub run/commit bindings
were checked during reconciliation. Earlier results remain in the immutable
history; this table is not a production approval.

| Domain | Repository | Status | Baseline | Last mainline run | Commit | Generated |
|---|---|---|---|---|---|---|
| DevSecOps | `joku-dev/ha-CPsWMS` | `pass` | `l1-baseline-v1.1.3` | `35131186298` | `4c57eb1cffcd1750c468ffba76a327bf78a8e8d3` | `2026-09-16T17:57:22Z` |
| Architecture | `joku-dev/ha-CPsWMS` | `PASS` | `architecture-baseline-l1-v0.1.0` | `35131185047` | `4c57eb1cffcd1750c468ffba76a327bf78a8e8d3` | `2026-09-16T17:55:49Z` |

Expected summaries:

| Domain | Expected result |
|---|---|
| DevSecOps | `16/16` controls pass, `0` fail |
| Architecture | `4/4` gates pass, `0` findings |

Interpretation:

- The recorded `ha-CPsWMS` mainline evidence demonstrates both governance domains at that revision.
- The result is not production approval or evidence of current freshness. A passing result alone does not establish the enforcement mode of a later run.

## Public Source Placeholders

The public source placeholders live under:

```text
docs/governance/source-documents/
```

Original source documents are withheld from the public repository. Current public placeholders:

| Source document | Governance domain |
|---|---|
| `DSCB-STD-SRC-001.public.md` | DevSecOps control baseline |
| `PRA-STD-SRC-001.public.md` | DevSecOps platform reference architecture |
| `DEVSECOPS-DIR-SRC-001.public.md` | DevSecOps directive |
| `DEVSECOPS-POL-SRC-001.public.md` | DevSecOps policy |
| `ARCH-SDD-SRC-001.public.md` | Architecture runtime governance |

Why this matters:

- The demo can start with the documents instead of the tooling.
- The governance repository can show which runtime artifacts came from which source.
- The architecture source document was not originally written as runtime governance, but the repo now contains a machine-readable addendum derived from it.

## Source Lineage

Open the generated source-lineage report:

```text
generated/reports/source-lineage-report.md
generated/reports/source-lineage-report.json
```

Expected summary at repository `4abe882` on 11 September 2026:

| Metric | Value |
|---|---:|
| Source documents | `21` |
| Source documents with lineage entries | `21` |
| Derived artifact links | `378` |
| Missing derived artifacts | `0` |

Interpretation:

- Every current source document has at least one lineage entry.
- The derived artifact links cover governance models, OPA policies, release packages, schemas, generated reports, indexes and the viewer.
- `0` missing derived artifacts means the lineage catalog currently points to files that exist in the repository.

This is the first demo proof point: the repository can explain how document-based governance flows into machine-readable governance assets.

## Local Prerequisites

Required tools:

```bash
python3
git
```

Useful tools:

```bash
gh
opa
```

Check GitHub authentication if you want to inspect or rerun GitHub Actions from the terminal:

```bash
gh auth status
```

The local viewer can be served from the generated viewer directory:

```bash
cd /workspace/devsecops-governance-framework/generated/viewer
python3 -m http.server 8000
```

Then open:

```text
http://localhost:8000/status-viewer.html
```

## Validate The Governance Repository

Run this in the governance repository:

```bash
cd /workspace/devsecops-governance-framework
python3 scripts/validate_runtime_governance.py
python3 scripts/validate_governance_repo.py
python3 -m unittest discover -s tests
```

Why:

- `validate_runtime_governance.py` checks the architecture runtime governance model, architecture schemas, marker catalog, generated reports and OPA readiness examples.
- `validate_governance_repo.py` checks DevSecOps controls, traceability, pipeline placement, governance requirements and source-document lineage.
- The unit tests cover the scripts that generate reports, indexes, release packages and viewer data.

Expected result:

```text
Runtime governance validation passed
Validation passed
OK
```

Interpretation:

- The governance repository is internally consistent.
- This step validates the governance engine and generated metadata, not a new application run.

## Demo Step 1: Show The Source-To-Artifact Chain

Open:

```text
docs/governance/source-documents/
generated/reports/source-lineage-report.md
```

Explain:

- The source documents are the human governance input.
- The lineage report is the machine-readable accountability layer.
- For architecture, the `ARCH-SDD-SRC-001.public.md` source document leads to architecture levels, quality markers, guardrails, OPA policies, schemas, release package and viewer output.
- For DevSecOps, the source documents lead to control models, policy-as-code, release baselines, generated reports and viewer output.

Expected interpretation:

- If a stakeholder asks "where did this check come from?", the demo can point to the source document and the derived artifacts.
- If a derived artifact is missing, validation should fail and the lineage report should show it.

## Demo Step 2: Show Released Baselines

Open the release packages:

```text
releases/l1/v1.1.3/baseline-package.md
releases/l1/v1.1.3/release-metadata.json
releases/architecture/l1/v0.1.0/baseline-package.md
releases/architecture/l1/v0.1.0/release-metadata.json
```

Explain:

- A baseline freezes a reviewed governance state.
- Application repositories should consume baseline tags or pinned commits, not an arbitrary local working tree.
- DevSecOps and architecture now use the same operating model: source documents, machine-readable model, OPA checks, released baseline, downstream execution, result intake and viewer status.

Expected interpretation:

- `l1-baseline-v1.1.3` is the current DevSecOps L1 demo baseline.
- `architecture-baseline-l1-v0.1.0` is the current architecture L1 demo baseline.
- The architecture baseline is intentionally early, but it is now versioned and demo-ready.

## Demo Step 3: Show Application Evidence

In the application repository, inspect governance evidence:

```bash
cd /workspace/ha-CPsWMS
find .governance -maxdepth 4 -type f | sort
```

Expected evidence areas:

```text
.governance/architecture/
.governance/devsecops/
```

For the current demo, the relevant files are:

```text
.governance/architecture/solution-baseline.json
.governance/architecture/release-compatibility-declaration.json
.governance/architecture/security-evidence.json
.governance/architecture/resilience-evidence.json
.governance/architecture/operation-evidence.json
.governance/architecture/feedback-evidence.json
.governance/devsecops/release-evidence.json
```

Why:

- The application repository owns its evidence.
- The governance repository owns the reusable rules, schemas, collectors and viewer.
- This split allows the same governance repo to evaluate multiple application repositories later.

### What The Architecture Evidence Looks Like

Each architecture evidence file is a small JSON review record. It does not contain all architecture documentation itself. Instead, it records who owns the evidence, whether it is approved, what repository files support it, and what limitations or follow-up actions remain.

Common architecture evidence fields:

| Field | Purpose |
|---|---|
| `evidence_type` | Tells the collector what kind of architecture evidence this file represents. |
| `status` | Review state. The demo expects `approved` for the passing mainline state. |
| `owner` | Accountable role for the evidence. |
| `approved_by` and `approval_date` | Review attribution for the demo evidence. |
| `baseline_version` | Used for baseline and compatibility evidence. |
| `summary` | Human explanation of what the evidence proves. |
| `evidence_refs` | Repository files that support the claim. |
| `known_limitations` | Visible caveats that do not currently fail the report-only demo. |
| `follow_up_actions` | Improvement backlog items for later hardening. |

Example architecture evidence shape:

```json
{
  "evidence_type": "solution_baseline",
  "status": "approved",
  "owner": "Solution Architect",
  "baseline_version": "ha-CPsWMS-demo-baseline",
  "approved_by": "Architecture Demo Review",
  "approval_date": "2026-07-02",
  "summary": "Demo solution baseline for the Home Assistant to Neo4j semantic world model capability.",
  "evidence_refs": [
    "docs/ARCHITECTURE.md",
    "docs/DEPLOYMENT.md",
    "docker-compose.yml"
  ],
  "known_limitations": [
    "Baseline is prepared for governance demo and should be formalized before production use."
  ],
  "follow_up_actions": [
    "Assign a permanent baseline owner.",
    "Replace demo approval with formal architecture review approval."
  ]
}
```

How to explain this in the demo:

- `solution-baseline.json` defines the app-owned solution baseline that the repository claims to be compatible with.
- `release-compatibility-declaration.json` states that the current release candidate is compatible with that baseline.
- `security-evidence.json`, `resilience-evidence.json` and `operation-evidence.json` provide release-critical support for security, resilience, deployment and runtime operation checks.
- `feedback-evidence.json` shows that operational or benchmark feedback can feed back into architecture improvement.
- The collector turns these files plus referenced repository artifacts into `generated/current-main/ha-cpswms/architecture-release-input.json`.

The tracked `generated/current-main/ha-cpswms/` files are retained local
explanatory artifacts for commit `4a86f0c`. Despite the directory name, they
are not the accepted September mainline result. Use the indexed producer
snapshots and run artifacts for the current result; use this local input only
to explain the collector/report format.

### What The DevSecOps Evidence Looks Like

The DevSecOps demo uses:

```text
.governance/devsecops/release-evidence.json
```

That file records approved demo evidence for repository protection, SBOM presence, vulnerability scan presence, artifact integrity, dependency source approval and pipeline gate behavior.

Representative shape:

```json
{
  "status": "approved",
  "owner": "DevSecOps Owner",
  "repository": {
    "protected_branch": true,
    "direct_push_allowed": false,
    "review_required": true
  },
  "sbom": {
    "exists": true,
    "linked_to_artifact": true
  },
  "vulnerability_scan": {
    "exists": true
  },
  "artifact": {
    "digest_exists": true,
    "digest_linked_to_artifact": true,
    "signature_exists": false
  },
  "pipeline": {
    "security_gates_enforced": true,
    "security_thresholds_exceeded": false
  }
}
```

Interpretation:

- Missing or incomplete evidence should become report findings.
- Approved evidence can turn findings into passing gates without changing the policy code.
- Demo evidence is intentionally transparent about limitations. It can pass the current report-only demo while still showing what must be improved for production-grade evidence.

## Demo Step 4: Show The App Workflows

In `joku-dev/ha-CPsWMS`, show these GitHub Actions workflows:

| Workflow | Purpose | Expected demo behavior |
|---|---|---|
| `DevSecOps Baseline` | Runs the released DevSecOps baseline | Passes on mainline |
| `DevSecOps Governance` | Runs DevSecOps governance with selectable mode | Explicit report-only for diagnostics; inspect the actual main-push mode |
| `Architecture Runtime Governance` | Runs architecture governance against `architecture-baseline-l1-v0.1.0` | Passes on mainline |

Explain:

- The app workflows execute in the application context.
- They publish artifacts in the application repository's GitHub Actions run.
- On pull requests, the governance checks run and produce artifacts, but they do not update the central governance viewer.
- On `push` to `main`, the relevant workflows send repository-dispatch intake events to the governance repository.
- DevSecOps can be manually switched between report-only and blocking behavior.
- Architecture is currently used as report-only for the live demo unless the workflow is configured to fail on findings.

Expected interpretation:

- Inspect the selected trigger and mode before a live run; the existing mainline integration must not be assumed nonblocking.
- New mandatory gates require readiness, accountable approval and a separate consumer change.

## Demo Step 5: Trigger A Live Mainline Refresh

Preferred demo flow:

1. Create a small pull request in `ha-CPsWMS`.
2. Merge it to `main`.
3. Watch the app repository workflows run on `main`.
4. Watch the governance repository intake workflows update the indexes and viewer.

Why:

- Mainline status is the most useful demo artifact.
- A mainline run proves that the status does not only come from local scripts.
- The viewer can show the latest real repository result.

Alternative:

1. Manually rerun the app workflows.
2. Use this only when a mainline change is not practical.

Interpretation:

- Pull-request runs are useful for validating a proposed change before merge.
- Manual reruns are useful for testing.
- A merged mainline change gives the strongest demo story because it refreshes the repository's official status.

## Demo Step 6: Observe Downstream App Runs

Current known-good app runs:

| Workflow | Run | Expected status |
|---|---:|---|
| Architecture Runtime Governance | `35131185047` | Success |
| DevSecOps Baseline | `35131186298` | Success |
| DevSecOps Governance | `35131185030` | Success |
| CI | `35131185111` | Success |

Open the run URLs:

```text
https://github.com/joku-dev/ha-CPsWMS/actions/runs/35131185047
https://github.com/joku-dev/ha-CPsWMS/actions/runs/35131186298
```

Explain:

- The app repo runs the checks and creates evidence artifacts.
- The architecture result is associated with `architecture-baseline-l1-v0.1.0`.
- The DevSecOps result is associated with `l1-baseline-v1.1.3`.

Expected interpretation:

- If a pull-request workflow succeeds, the proposed change has report evidence in the app repository, but the central viewer is not expected to update.
- If a `main` push workflow succeeds and the viewer updates, the downstream-to-governance loop is working.
- If a `main` push workflow succeeds but the viewer does not update, inspect intake, its bot PR review/merge, and Pages publication.

## Demo Step 7: Observe Governance Intake

In the governance repository, inspect the intake workflows:

```text
.github/workflows/intake-governance-result.yml
.github/workflows/intake-architecture-result.yml
.github/workflows/intake-evidence-trust.yml
.github/workflows/retry-collection-attempt.yml
```

Explain:

- The app repository sends result metadata and artifacts to the governance repository.
- The governance repository updates:

```text
status/repository-results-index.json
status/architecture-results-index.json
generated/viewer/status-viewer.html
```

- The intake workflows regenerate indexes and the viewer before proposing scoped bot PRs. Official main state changes after review and merge.
- Distinct consumer runs retain separate concurrency identities. Concurrent PR conflicts require reconciliation of all accepted records and regenerated shared projections before final review.
- Failed collections are prepared as append-only records and proposed through the publication path before the intake workflow ends in failure. A failed publication remains visible in Actions and still needs recovery; unmerged records are not yet accepted main state. A retryable record can be routed back through the matching existing
  intake with `Retry Collection Attempt`.

Expected interpretation:

- Intake commits are not manual demo cosmetics; they are part of the governance feedback loop.
- Concurrent consumer events should converge without discarding a distinct
  intake. Collection failures remain visible until a matching successful
  snapshot resolves them.

## Demo Step 8: Interpret The Viewer

Open:

```text
http://localhost:8000/status-viewer.html
```

Show these sections:

| Viewer section | What to explain |
|---|---|
| Repository Governance Status | DevSecOps and Architecture status side by side for each repository |
| Evidence Trust | Confidence in the captured evidence, shown independently from the governance outcome |
| Replay Triage | Recorded replay results versus their current report-only interpretation and remediation action |
| Runtime Governance | End-to-end demo status, architecture gates and DevSecOps release result |
| Repository Execution | Mainline history, branch validation, manual diagnostics and run links |
| Intake Health | 30-day execution count, observed success rate, p50/p95 duration and latest-result age without an SLO verdict |
| Collection Attempts | Open, resolved and permanent report-only intake failures |
| Artifacts & Machine Data | Links to indexes, reports, lineage and generated machine-readable files |

Expected interpretation:

- DevSecOps should show `pass` for baseline `l1-baseline-v1.1.3`.
- Architecture should show `PASS` for baseline `architecture-baseline-l1-v0.1.0`.
- Existing pre-Trust snapshots should show evidence Trust `unverified` without changing either governance result.
- The latest ha-CPsWMS DevSecOps run `35131186298` retains a report-only
  Replay `fail` for cross-commit subject reuse. Architecture run `35131185047`
  has Replay `pass`. Passing controls do not clear the separate Trust finding.
  Historical replay assessments remain available under Evidence → Replay.
- A resolved Collection Attempt proves only that collection later succeeded;
  it does not upgrade or weaken the collected governance outcome.
- Intake Health derives its counts and durations from the accepted operation
  events, including these two intakes. Read the displayed observation window;
  accepted telemetry is not a production SLO and can differ from the daily
  report's live Actions observations.

- The viewer is the demo cockpit: it makes the current governance state visible without opening every raw JSON file.

## Report-Only Versus Blocking

Use report-only for new demo consumers. Do not change the actual ha-CPsWMS
legacy mode for a presentation; any new blocking demonstration needs a scoped
readiness review, approval and separate consumer configuration change.

| Domain | Report-only behavior | Blocking behavior |
|---|---|---|
| DevSecOps | Findings are reported in summaries, artifacts and viewer data | Manual workflow mode can fail on findings |
| Architecture | Findings are reported in summaries, artifacts and viewer data | Can be hardened by enabling fail-on-findings in the consuming workflow |

Why:

- Report-only mode is the safest way to demonstrate rollout.
- New blocking requires the current readiness assessment, accountable approval and a separate consumer change; agreement on evidence paths alone is insufficient.
- Both modes should use the same evidence and policy logic so the governance result remains comparable.

Interpretation:

- A report-only failure is still a real governance signal.
- Blocking is an enforcement choice, not a different governance model.

## What The Demo Proves

The demo proves that:

1. Governance source documents can be linked to machine-readable artifacts.
2. DevSecOps controls and architecture topics can use the same baseline mechanics.
3. Application repositories can provide evidence without copying policy logic.
4. GitHub Actions can run governance checks on the app repository.
5. Governance repository intake can collect downstream results.
6. A viewer can show mainline governance status for both DevSecOps and architecture.
7. The Governance Graph can explain how repositories, runs, commits, baselines, evidence, Trust, snapshots, source documents, and derived artifacts relate.
8. Multi-consumer readiness can be reproduced from the registry, isolated
   result paths, portfolio projection, intake workflow concurrency, and
   telemetry identities.

## What The Demo Does Not Yet Prove

The demo does not yet prove:

- formal production approval
- complete enterprise security certification
- fully automated semantic extraction from every source document
- live SBOM, vulnerability scanner or artifact-signing integrations for every application
- live operational monitoring integration
- mature architecture L2/L3 rollout

Interpretation:

- The demo is a working governance loop.
- Some evidence is still demo evidence or manually curated governance evidence.
- The next maturity step is tool integration and broader application coverage.

## Troubleshooting

### Viewer Is Stale

Regenerate it:

```bash
cd /workspace/devsecops-governance-framework
python3 scripts/generate_governance_graph.py
python3 scripts/generate_status_viewer.py
```

Then refresh:

```text
http://localhost:8000/status-viewer.html
```

### Source Lineage Looks Wrong

Regenerate and validate:

```bash
python3 scripts/generate_source_lineage_report.py
python3 scripts/validate_governance_repo.py
```

Expected result:

```text
Validation passed
```

### Architecture Findings Appear

Inspect the architecture report artifact from the app workflow or the local generated report.

Typical causes:

- missing `.governance/architecture/*.json` evidence
- evidence does not match the schema
- baseline or compatibility declaration is missing
- runtime or feedback evidence is below the expected marker level

Interpretation:

- The finding should describe the missing evidence and the expected remediation.
- In report-only mode, the workflow can still complete while making the issue visible.

### DevSecOps Findings Appear

Inspect the DevSecOps report artifact from the app workflow.

Typical causes:

- missing `.governance/devsecops/release-evidence.json`
- missing CI, dependency or artifact evidence
- policy candidate configured as blocking in the selected mode

Interpretation:

- Report-only mode should publish the finding.
- Blocking mode should fail the workflow when the finding is configured as enforceable.

### Intake Does Not Update The Viewer

Check the governance repository Actions tab for:

```text
Intake Downstream Governance Result
Intake Downstream Architecture Result
Intake Typed Evidence Trust
Retry Collection Attempt
```

Use the viewer's `Collection Attempts` section to distinguish an `open`,
`resolved`, or `permanent` collection failure. For an `open` attempt:

1. Open the matching JSON record below `status/collection-attempts/`.
2. Confirm that every error is marked `retryable` and address the recorded
   authentication, availability, or artifact cause.
3. Start `Retry Collection Attempt` and provide that repository-relative path.
4. Follow the newly dispatched intake workflow.
5. Review and merge the successful intake PR, then verify the published viewer; the
   lifecycle should become `resolved` while the original failure remains.

Do not retry a `permanent` attempt without correcting and producing new source
evidence. Concurrent operational PR conflicts require branch reconciliation and
regeneration before review/merge; this is separate from Collection Attempt recovery.

### GitHub Authentication Fails

Use:

```bash
gh auth login
gh auth status
```

The demo also needs the application repository to have a token or secret that can dispatch result intake to the governance repository.
