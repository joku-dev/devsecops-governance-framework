# Intake Operation Telemetry

## Purpose

Intake operation telemetry records every central DevSecOps, architecture, and
typed-evidence intake execution. It provides the event history needed to
calculate reliable operational indicators such as success rate, failure rate,
and intake duration in the report-only Intake Health projection.

The telemetry is additive, append-only, and report-only. It does not change a
governance outcome, Evidence Trust, `latest_result`, portfolio status, or
delivery enforcement.

## Why A Separate Event Is Needed

The existing stores answer different questions:

| Store | Question |
|---|---|
| Result snapshot | What governance or Evidence result was accepted? |
| Collection attempt | Which failed or partial collection requires operator attention or retry? |
| Intake operation event | Did a central intake execution succeed, fail, or remain partial, and how long did it take? |

A success rate needs both successful and unsuccessful events. Result snapshots
alone are not a safe denominator because idempotent intake can succeed without
creating a new snapshot, while failed collection attempts contain only failure
history.

## Contract And Storage

| Artifact | Location |
|---|---|
| Schema | `schemas/intake-operation-event.schema.json` |
| Schema-valid example | `docs/examples/intake-operation-event.example.json` |
| Recorder | `scripts/record_intake_event.py` |
| Event ledger | `status/intake-events/` |
| Conflict quarantine | `status/intake-conflicts/intake-events/` |

Each event records:

- consumer repository and downstream run
- intake type: DevSecOps governance, architecture governance, or typed evidence
- evidence type, collector, and artifact
- central intake workflow, run, and run attempt
- trigger event
- start and completion timestamps
- duration in milliseconds
- `success`, `partial`, or `failed`
- a structured error for partial or failed events

## Event Identity And Append-Only Behavior

The event identity binds:

```text
consumer repository
+ intake and evidence type
+ collector id and version
+ downstream run and artifact
+ central workflow, run and run attempt
```

Re-running the recorder with an identical event is idempotent. A different
payload with the same event identity does not overwrite history; it creates a
report-only conflict under `status/intake-conflicts/intake-events/`.

A retry started through `Retry Collection Attempt` creates a new central
workflow run and therefore a new telemetry event. The original failure remains
available for audit.

## Workflow Integration

Telemetry is integrated into:

- `.github/workflows/intake-governance-result.yml`
- `.github/workflows/intake-architecture-result.yml`
- `.github/workflows/intake-evidence-trust.yml`

Each workflow captures a start timestamp immediately before collection, runs
the existing intake, then records the operation outcome before regeneration,
validation, and an operational PR. The proposed commit includes
`status/intake-events/`; review and merge publish accepted telemetry on `main`.

If collection fails, the workflow records both:

1. a collection attempt for recovery and lifecycle handling
2. an intake operation event for operational measurement

The workflow still ends as failed after those report-only records have been
proposed for review, when recording and validation succeeded. A telemetry
recorder failure also makes the workflow fail visibly. The workflow-run
history can therefore contain failures absent from accepted event history.

## Manual Recorder Example

```bash
python3 scripts/record_intake_event.py \
  --repository-id owner/repo \
  --run-id 42 \
  --evidence-type governance_result \
  --collector-id central-governance-intake \
  --artifact-name governance-control-evaluation \
  --intake-type devsecops_governance \
  --status success \
  --started-at 2026-07-17T12:00:00Z \
  --completed-at 2026-07-17T12:00:03Z \
  --intake-repository-id governance/framework \
  --intake-workflow-name "Intake Downstream Governance Result" \
  --intake-run-id 84 \
  --intake-run-attempt 1 \
  --trigger-event repository_dispatch
```

For a failed or partial event, add `--error-code` and `--message`. Successful
events cannot contain errors. Completion cannot precede start, and timestamps
must include a timezone.

In GitHub Actions, repository, workflow, intake run, run attempt, and trigger
event default from the standard `GITHUB_*` environment variables.

## Validated Smoke Test

The three instrumented central intake paths were exercised on 2026-07-17 with
existing mainline evidence from
`joku-dev/governance-framework-demo-consumer`:

| Intake | Central run | Outcome | Recorded duration |
|---|---:|---|---:|
| DevSecOps governance | `29613365725` | success | 2 s |
| Architecture governance | `29613411052` | success | 3 s |
| Typed evidence | `29613460601` | success | 2 s |

All runs were started with `workflow_dispatch`. They created schema-valid
append-only operation events, created no Collection Attempts, and left the
semantic content of the latest result indexes unchanged. The DevSecOps run
also exposed a legacy ledger identity that lacked `artifact_digest`; the
resulting report-only conflict remains immutable audit history. Subsequent
intake treats this one-field legacy enrichment as idempotent when core context
and subject digests are unchanged, while different present artifact digests
remain conflicts.

The July runs above are historical smoke evidence. The accepted projection
of 11 September 2026 contains six successful events in its 30-day window,
covering ha-CPsWMS and the neutral demo. See the
[Intake Health projection](intake-health-projection.md) for the dated metrics.

## Current Limits

- Telemetry begins when the instrumented workflows are merged; historical
  snapshots are not converted into synthetic events.
- No SLO or alert threshold is defined by this contract.
- The derived health projection remains informational and does not change
  viewer, portfolio, Trust, or enforcement status.
- Duration currently measures the central collection step boundary established
  by the workflow, not downstream evidence production time.
- Events are stored in Git and therefore share the repository's current write
  throughput and concurrency limits.

## Intake Health Projection

`scripts/generate_intake_health.py` now creates the schema-valid read model at
`status/intake-health.json`. It includes success and failure rate over an
explicit 30-day window, duration percentiles, dimensional event counts,
Collection Attempt lifecycle counts, append-only conflict count, and latest
result age. See `docs/operations/evidence/intake-health-projection.md` for the
contract and interpretation rules.

Thresholds and alerts should be approved only after enough real events exist to
establish a useful baseline.

## Validation

```bash
python3 scripts/validate_governance_repo.py
python3 -m unittest tests.test_record_intake_event
python3 -m unittest tests.test_generate_intake_health
python3 -m unittest tests.test_result_ledger
python3 -m unittest tests.test_intake_workflow_concurrency
./scripts/validate_all.sh
mkdocs build --strict
```
