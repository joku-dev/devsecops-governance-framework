# Operations Guides

Current capability reference: [function catalog](repository-function-catalog.md)
and [technical inventory](repository-technical-function-inventory.md).
For the accepted manual GRS-002 pilot, use the
[current lifecycle operating state](../status/governance-lifecycle-current-state.md).

## Purpose

This folder contains practical guidance for people who operate, maintain or
publish the DevSecOps governance repository.

Guides explain how to perform recurring repository tasks. They do not define
new governance policy, source-document status, controls, schemas or baseline
behavior by themselves.

## Guides

| Guide | Purpose |
|---|---|
| [Detailed Function Catalog](repository-function-catalog.md) | German catalog of twenty functional areas, processing steps, implementation files and limitations. |
| `docs/operations/guides/how-to-use-this-repo.md` | General orientation for using the governance repository. |
| `docs/operations/guides/beginner-step-by-step-operations-guide.md` | Beginner-friendly operational walkthrough. |
| `docs/operations/guides/how-to-add-a-new-artifact.md` | Practical step-by-step guide for adding a new artifact safely. |
| `docs/operations/guides/how-to-update-baseline-input-documents.md` | Maintenance flow for upstream baseline input document changes. |
| `docs/operations/guides/mkdocs-and-github-pages-step-by-step.md` | Documentation publishing and MkDocs validation guide. |
| `docs/operations/guides/evidence-and-governance-hardening-guide.md` | Operating guide for the append-only ledger, graph, collectors, provenance and validation. |

## Boundary

Governance process documents, intake operating models, waiver standards and
enforcement options remain outside this folder until they are reviewed through
a focused process-document migration.
