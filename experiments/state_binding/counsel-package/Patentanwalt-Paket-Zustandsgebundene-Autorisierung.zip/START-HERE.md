# Vertrauliche Unterlagen für die Patentberatung

Zuerst das PDF im Hauptverzeichnis lesen. Die sechs Kapitel liegen editierbar
unter documents/. source/ enthält die ausgewählten unveränderten Quelldateien;
evidence/ enthält die originalen Versuche und Prüfberichte.

Paketintegrität prüfen (lesend, ohne Entpacken des geprüften ZIPs):

    python3 verify_package.py PFAD_ZUM_ZIP --expect-zip-sha256 EXTERN_AUFBEWAHRTER_DIGEST

Automatisierte Versuche unabhängig prüfen (nach Entpacken dieses Pakets):

    python3 source/experiments/state_binding/verify_evidence.py evidence/run-001.zip --expect-manifest-sha256 e8a903751e3e3f040371329f8f8ef2910376f72decd42a033f3620b50caf4628

Der technische Quellcodeauszug ist kein vollständiger Repository-Checkout.
Die persönliche Offline-Prüfung und eine Wiederholung der Gesamttests sind im
vollständigen privaten Repository beschrieben. Den Code aus einer tatsächlichen
persönlichen Freigabe nicht nochmals zur Ausführung verwenden.

Das Paket ist nicht verschlüsselt. Für den vereinbarten vertraulichen Kanal
bestimmt. Es wurde nicht automatisch an einen Empfänger versendet.
