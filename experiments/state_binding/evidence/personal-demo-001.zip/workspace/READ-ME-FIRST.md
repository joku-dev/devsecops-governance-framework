# Persönlicher, privater Demonstrationslauf

Bitte personal-request.json vollständig prüfen. Die darin gebundene Aktion schreibt genau ein lokales Testartefakt. Alle Beobachtungen bleiben synthetische Testdaten.

Die benannte Person (GitHub-ID 81616324) kann danach PERSONAL-STATEMENT.txt selbst als Kommentar unter https://github.com/joku-dev/devsecops-governance-framework/pull/176 abgeben.

Codex gibt diese Erklärung nicht stellvertretend ab. Der folgende Ausführungsbefehl prüft sie direkt bei GitHub unter der lokalen Schreibsperre. Jede gebundene Änderung erfordert einen neuen Antrag.

```bash
.venv-validation/bin/python experiments/state_binding/human_demo.py execute --workspace experiments/state_binding/human-demo/session-1
```
