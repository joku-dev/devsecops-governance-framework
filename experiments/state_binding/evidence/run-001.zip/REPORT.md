# Confidential prototype experiment results

Source commit: `68849a1011097e9ad985844110b12c2dd7f18e3b`.
Exact source bytes are additionally bound by the source manifest.

Experiments: 18; passed: 18.
All automated authorizations are test fixtures. Patentability is not assessed.

| Experiment | Outcome |
|---|---|
| unchanged | PASS |
| new_evidence | PASS |
| audit_only_history | PASS |
| implementation_changed | PASS |
| role_changed | PASS |
| profile_changed | PASS |
| action_changed | PASS |
| provider_revoked | PASS |
| provider_edited | PASS |
| provider_deleted | PASS |
| state_root_changed | PASS |
| implementation_without_binding | PASS |
| history_without_history_root | PASS |
| history_without_history_preconditions | PASS |
| state_without_state_root | PASS |
| retry | PASS |
| revocation_after_change | PASS |
| concurrent_publication | PASS |

## Interpretation

History roots overlap existing head/sequence safeguards: removing only the history root still rejects stale history.
Removing all history preconditions admits a history-only change despite an equal semantic state.
Implementation binding rejects changed configured execution semantics; omitting it admits that change.
State-root checking independently rejects an incorrectly claimed semantic root. This does not prove a novel security property over a validated head plus deterministic replay.
Existing pilot regression suites are retained as comparison, not relabelled as a weaker baseline.
The publication is an actual atomic JSON artifact in the local ledger. No consumer deployment was performed.
