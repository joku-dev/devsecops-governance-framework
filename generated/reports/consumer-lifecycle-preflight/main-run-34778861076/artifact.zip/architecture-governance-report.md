# Architecture Runtime Governance Report

## Target

- Repository: `/home/runner/work/governance-framework-demo-consumer/governance-framework-demo-consumer/application`
- Commit: `915aeed`
- Release ID: `915aeed2507ba3cc60fad5cd6a7b2415505a1ac9`
- Detected services: `0`

## Gate Summary

| Gate | Status | Findings |
|---|---:|---:|
| Architecture Readiness | FINDINGS | 5 |
| Integration Readiness | FINDINGS | 6 |
| Operation Readiness | FINDINGS | 2 |
| Release Readiness | FINDINGS | 12 |

## Detailed Evidence

Mode: `report-only`

| Evidence type | Coarse area | Status | Owner | Path |
|---|---|---|---|---|
| `compatibility_matrix` | `release_compatibility_declaration` | `reviewed` | Product Architect | `.governance/architecture/compatibility-matrix.json` |
| `feedback_evidence` | `feedback_evidence` | `reviewed` | Architecture Review Owner | `.governance/architecture/feedback-evidence.json` |
| `observability_evidence` | `operation_evidence` | `reviewed` | Operations Owner | `.governance/architecture/observability-evidence.json` |
| `operation_evidence` | `operation_evidence` | `reviewed` | Operations Owner | `.governance/architecture/operation-evidence.json` |
| `release_compatibility_declaration` | `release_compatibility_declaration` | `reviewed` | Product Architect | `.governance/architecture/release-compatibility-declaration.json` |
| `resilience_evidence` | `resilience_evidence` | `reviewed` | Solution Architect | `.governance/architecture/resilience-evidence.json` |
| `security_evidence` | `security_evidence` | `reviewed` | Security Owner | `.governance/architecture/security-evidence.json` |
| `solution_baseline` | `solution_baseline` | `reviewed` | Solution Architect | `.governance/architecture/solution-baseline.json` |

## Report-Only Advisories

| Severity | Evidence type | Coarse area | Message |
|---|---|---|---|
| `info` | `threat_model` | `security_evidence` | Recommended detailed evidence `threat_model` is not declared. |
| `info` | `interface_contract` | `release_compatibility_declaration` | Recommended detailed evidence `interface_contract` is not declared. |
| `info` | `deployment_manifest` | `deployment_evidence` | Recommended detailed evidence `deployment_manifest` is not declared. |
| `info` | `model_based_architecture` | `solution_baseline` | Recommended detailed evidence `model_based_architecture` is not declared. |


## Findings

### Architecture Readiness

- RG-ARCH-READY: Architecture-readiness marker B3 requires score 3 or a valid exception; current score is 1.
- RG-ARCH-READY: Architecture-readiness marker P3 requires score 3 or a valid exception; current score is 1.
- RG-ARCH-READY: Architecture-readiness marker P7 requires score 3 or a valid exception; current score is 1.
- RG-ARCH-READY: Architecture-readiness marker S1 requires score 3 or a valid exception; current score is 1.
- RG-ARCH-READY: Architecture-readiness marker S2 requires score 3 or a valid exception; current score is 1.

### Integration Readiness

- RG-INTEGRATION-READY: Integration-readiness marker E3 requires score 3 or a valid exception; current score is 1.
- RG-INTEGRATION-READY: Integration-readiness marker E5 requires score 3 or a valid exception; current score is 1.
- RG-INTEGRATION-READY: Integration-readiness marker P5 requires score 3 or a valid exception; current score is 1.
- RG-INTEGRATION-READY: Integration-readiness marker P6 requires score 3 or a valid exception; current score is 1.
- RG-INTEGRATION-READY: Integration-readiness marker S3 requires score 3 or a valid exception; current score is 1.
- RG-INTEGRATION-READY: Integration-readiness marker S4 requires score 3 or a valid exception; current score is 1.

### Operation Readiness

- RG-OPERATION-READY: Operation-readiness marker B5 requires score 4 or a valid exception; current score is 3.
- RG-OPERATION-READY: Operation-readiness marker P11 requires score 4 or a valid exception; current score is 3.

Recommended actions:
- **Strengthen architecture feedback loop**: Link operational findings, demo findings or benchmark trends to owned improvement actions, technical debt items or architecture runway.
  Evidence: `operational_finding`, `improvement_backlog_item`, `technical_debt_item`
- **Verify observability evidence**: Add runtime metrics, health indicators, monitoring dashboard evidence or operational diagnostics that prove observability works.
  Evidence: `monitoring_dashboard`, `runtime_metric`, `health_indicator`

### Release Readiness

- RG-RELEASE-READY: Release compatibility declaration must be approved.
- RG-RELEASE-READY: Release-critical architecture marker E6 requires score 4 or a valid exception; current score is 3.
- RG-RELEASE-READY: Release-critical architecture marker P10 requires score 4 or a valid exception; current score is 3.
- RG-RELEASE-READY: Release-critical architecture marker P13 requires score 4 or a valid exception; current score is 3.
- RG-RELEASE-READY: Release-critical architecture marker P5 requires score 4 or a valid exception; current score is 1.
- RG-RELEASE-READY: Release-critical architecture marker P6 requires score 4 or a valid exception; current score is 1.
- RG-RELEASE-READY: Release-critical architecture marker P8 requires score 4 or a valid exception; current score is 3.
- RG-RELEASE-READY: Release-critical architecture marker P9 requires score 4 or a valid exception; current score is 1.
- RG-RELEASE-READY: Release-critical architecture marker S3 requires score 4 or a valid exception; current score is 1.
- RG-RELEASE-READY: Release-critical architecture marker S5 requires score 4 or a valid exception; current score is 3.
- RG-RELEASE-READY: Release-critical architecture marker S6 requires score 4 or a valid exception; current score is 3.
- RG-RELEASE-READY: Release-critical architecture marker S8 requires score 4 or a valid exception; current score is 3.

Recommended actions:
- **Create release compatibility declaration**: Create and approve a release compatibility declaration that identifies the supported solution baseline, interface versions, data versions, deployment assumptions, security assumptions, known limitations and approval roles.
  Evidence: `release_compatibility_declaration`, `product_compatibility_matrix`, `approval_record`
- **Verify enterprise security guardrail evidence**: Add verified security evidence such as threat model review, vulnerability scan result, crypto/security review or security architecture review.
  Evidence: `security_architecture_review`, `vulnerability_scan_result`, `security_test_evidence`
- **Verify product resilience behavior**: Add failure-mode, restart, recovery, degraded-mode or DIL behavior tests.
  Evidence: `failure_mode_test`, `recovery_test_result`, `degraded_mode_evidence`
- **Declare product release compatibility**: Add a product release compatibility declaration showing supported baselines, interface versions, data versions, deployment assumptions, exceptions and approvals.
  Evidence: `product_release_compatibility_declaration`, `compatibility_evidence`, `release_review_record`
- **Verify product security implementation**: Add product-level security verification evidence for authentication, authorization, crypto usage, logging and vulnerability handling.
  Evidence: `product_security_concept`, `vulnerability_scan_result`, `security_test_evidence`
- **Verify solution security evidence**: Define and verify solution trust zones, identity assumptions, crypto assumptions, logging/audit expectations and product security declarations.
  Evidence: `solution_threat_model`, `trust_zone_model`, `security_test_evidence`
- **Complete release architecture evidence**: Link the solution baseline to compatible product releases, interface versions, data contracts and deployment assumptions.
  Evidence: `solution_release_baseline`, `product_compatibility_matrix`, `release_declaration`
- **Verify solution resilience scenarios**: Add tested degraded-mode, failover, recovery or disconnected/intermittent/limited connectivity scenarios.
  Evidence: `degraded_mode_scenario`, `resilience_test_result`, `recovery_evidence`
